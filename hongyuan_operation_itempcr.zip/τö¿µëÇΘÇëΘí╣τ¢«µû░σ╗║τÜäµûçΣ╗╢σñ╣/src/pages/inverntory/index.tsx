import React from 'react';

function Inverntory() {
  return (
    <div>
      Inverntory
    </div>
  );
}

export default Inverntory;
