/*
 * @Author: 二齐 1321703149@qq.com
 * @Date: 2022-09-09 02:37:04
 * @LastEditors: 二齐 1321703149@qq.com
 * @LastEditTime: 2022-09-15 18:30:08
 * @FilePath: /simple-react-0909/src/pages/homePage/index.tsx
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */


import { useEffect } from 'react';
import { Layout } from 'antd';
import HomePageHeader from './homePageHeader';
import HomePageSider from './homePageSider';
import HomePageContent from './homePageContent';

const HomePage = () => {
    useEffect(() => {
        console.log('动了');
        
    }, []);

    return (
        <Layout className='home-page'>
            <HomePageHeader></HomePageHeader>
            <Layout hasSider>
                <HomePageSider></HomePageSider>
                <HomePageContent></HomePageContent>
            </Layout>
            {/* <Footer>Footer</Footer> */}
        </Layout>
    );
}

export default HomePage;
