import React from 'react';
import './index.scss';

const ITEMS_NAME = '必要';
function HomePageHeader() {
    return <div className="home-page-header">
        <span>{ITEMS_NAME}</span>
        <span>{ITEMS_NAME}</span>
        <span>运营管理</span>
    </div>;
}

export default HomePageHeader;
