
import React from 'react';
import { Cascader } from 'antd';
import CommodityContent, { ItemsTableList } from './commodityContent';
import SelectPlatform from '../../components/selectPlatform';
import SearchInput from '../../components/searchInput';
import './index.scss';
import { getCategoryOptions, reqSearchCommodity } from './api';

interface IProps {
}
interface IState {
    /** 类目选择 */
    categoryoptions: categoryoptions[];
    /** 商品列表 */
    itemTableList: ItemsTableList[];
    /** 搜索数据 */
    searchData: SearchData;
}

/** 类目选择项 */
interface categoryoptions {
    /** 商品id */
    categoryId?: string;
    /** 类目名称 */
    categoryName?: string;
    /** 子集 */
    children?: categoryoptions[];
}

/** 搜索内容 */
interface SearchData {
    /** 类目 */
    category: string[];
    /** 平台 */
    platform: string[];
    /** 关键词搜索 */
    keyword: string;
    /** 每页条数 */
    pageCount: number;
    /** 页码 */
    pageSize: number;
}


/** 商品管理页面 */
class CommodityManagement extends React.Component<IProps, IState>  {
    constructor (props: IProps) {
        super(props);
        this.state = {
            categoryoptions: [],
            itemTableList: [],
            searchData: {
                category: [],
                platform: ['all'],
                keyword: '',
                pageCount: 20,
                pageSize: 1,

            },
        };
    }
    componentDidMount (): void {
        // 初始化数据
        this.initData();
    }
    /**
     * 初始化数据
     */
    initData = async () => {
        const { searchData } = this.state;
        // 获取类目数据
        const categoryoptions: any = getCategoryOptions();
        // 设置默认数据 - 第一条数据
        const firstData: string[] = [];
        const category = this.getFirstCategoryData(categoryoptions, firstData);
        this.setState({ categoryoptions, searchData: { ...searchData, category } }, () => {
            this.handleSearch();
        });
    }

    /**
     * 获取第一个类目数据
     * @param categoryoptions
     * @param arr
     * @returns
     */
    getFirstCategoryData = (categoryoptions: any, arr: string[]): string[] => {
        categoryoptions?.forEach((item: any, index: number) => {
            if (index === 0) {
                arr.push(item.categoryId);
                if (item.children) {
                    this.getFirstCategoryData(item.children, arr);
                }
            }
        });
        return arr;
    }

    /**
     * 处理类目改变
     * @param val
     */
    handleCategoryChange = (val: string[]) => {
        const { searchData } = this.state;
        searchData.category = val;
        this.setState({ searchData }, () => {
            this.handleSearch();
        });
    }

    /**
     * 处理平台改变
     * @param val
     */
    handlePlatformChange = (val : string[]) => {
        const { searchData } = this.state;
        searchData.platform = val;
        this.setState({ searchData }, () => {
            this.handleSearch();
        });
    }

    /**
     * 处理inputs搜索
     * @param val
     */
    handleInputSearch = (val: string) => {
        const { searchData } = this.state;
        searchData.keyword = val;
        this.setState({ searchData }, () => {
            this.handleSearch();
        });
    }
    /**
     * 改变页码选项
     */
    handleChangePageSize = (val: number) => {
        const { searchData } = this.state;
        searchData.pageSize = val;
        this.setState({ searchData }, () => {
            this.handleSearch();
        });
    }

    /**
     * 真正开始处理搜索
     * @returns
     */
    handleSearch = async () => {
        const { searchData } = this.state;
        const res = await reqSearchCommodity(searchData);
        console.log(res, 'res????');
        // 整理成能穿入tablelist的文件 itemTableList
        const itemTableList = this.handleItemTableList(res.data.objs);
        // console.log(itemTableList, '??????itemTableList');
        this.setState({ itemTableList });
    }

    /**
     * 处理成table格式数据
     * @returns
     */
    handleItemTableList = (data: any) => {
        let tableData = [];
        tableData = data.map(item => {
            return {
                name: item.productName,
                url: item.portalSquareImgUrl,
                key: item.spuId,
                category: item.salePoint,
                liangdao: '',
            };
        });
        return tableData;
    }
    render () {
        const { categoryoptions, itemTableList, searchData  } = this.state;
        return <div className='commodity-management'>
            <div className="commodity-management-title location">
                <Cascader
                    value={searchData.category}
                    options={categoryoptions}
                    onChange={this.handleCategoryChange}
                    allowClear={false}
                    style={{ width: 324 }}
                    fieldNames={{ label: 'categoryName', value: 'categoryId' }}/>
                <div className="title-input">
                    <SelectPlatform handleSelectChange={this.handlePlatformChange}></SelectPlatform>
                    <SearchInput from='productList' handleInputSearch={this.handleInputSearch}/>
                </div>
            </div>
            <div className="commodity-management-content">
                <CommodityContent itemTableList={itemTableList} changePageSize={this.handleChangePageSize}></CommodityContent>
            </div>
        </div>;
    }
}

export default CommodityManagement;
