import axios from '../../services/axios';

interface CategoryData {
    categoryId?: number;
    categoryName?: string;
    children?: CategoryData[];
}
/**
 * 请求获取商品列表
 */
export const reqSearchCommodity = async (params) => {
    let commodityList: any = [];
    console.log(params, '请求参数');
    await axios.post('/itemManage/getItemList', params)
        .then((response) => {
            commodityList = response.data.data;
        })
        .catch((error) => {
            console.log(error);
        });
    return commodityList;
};

/**
 * 类目数据转成树形
 * @param arr
 * @returns
 */
const setTreeData = (arr: CategoryData[]) => {
    //  删除所有 children,以防止多次调用
    arr.forEach((item: CategoryData) => {
        delete item.children;
    });
    const map: any = {}; // 构建map
    arr.forEach(i => {
        map[i.categoryId] = i; // 构建以area_id为键 当前数据为值
    });

    const treeData: CategoryData[] = [];
    arr.forEach((child: any) => {
        const mapItem = map[child.parentId]; // 判断当前数据的parent_id是否存在map中
        if (mapItem) { // 存在则表示当前数据不是最顶层数据
            // 注意: 这里的map中的数据是引用了arr的它的指向还是arr，当mapItem改变时arr也会改变,踩坑点
            (mapItem.children || (mapItem.children = [])).push(child); // 这里判断mapItem中是否存在children, 存在则插入当前数据, 不存在则赋值children为[]然后再插入当前数据
        } else { // 不存在则是组顶层数据
            treeData.push(child);
        }
    });
    return treeData;
};


const ITEM_LIST_URL = 'Distributeitem/getItemListByOriginNumIid';
/**
 * 分销商列表搜索接口
 */
export const reqSearchDistributorList = (params) => {
    return new Promise((resolve, reject) => {
        axios.get(ITEM_LIST_URL, params, {
            baseURL: 'https://devweb688.aiyongtech.com/',
            headers: { 'X-From-App': 'biyao' },
        })
            .then(response => {
                // if (response.data.code === '4005') {
                //     window.localStorage.clear();
                //     location.reload()
                // }
                resolve(response.data);
            }, err => {
                reject(err);
            })
            .catch((error) => {
                reject(error);
            });
    });
};


const data = [
    {
        "categoryId": 1,
        "categoryName": "家装建材",
        "parentId": 0
    },
    {
        "categoryId": 2,
        "categoryName": "鞋靴",
        "parentId": 0
    },
    {
        "categoryId": 3,
        "categoryName": "服饰内衣",
        "parentId": 0
    },
    {
        "categoryId": 4,
        "categoryName": "母婴",
        "parentId": 0
    },
    {
        "categoryId": 7,
        "categoryName": "眼镜",
        "parentId": 0
    },
    {
        "categoryId": 8,
        "categoryName": "家具",
        "parentId": 0
    },
    {
        "categoryId": 10,
        "categoryName": "女鞋",
        "parentId": 2
    },
    {
        "categoryId": 13,
        "categoryName": "童鞋",
        "parentId": 2
    },
    {
        "categoryId": 14,
        "categoryName": "运动鞋",
        "parentId": 2
    },
    {
        "categoryId": 15,
        "categoryName": "男鞋",
        "parentId": 2
    },
    {
        "categoryId": 19,
        "categoryName": "运动户外",
        "parentId": 0
    },
    {
        "categoryId": 21,
        "categoryName": "内衣",
        "parentId": 3
    },
    {
        "categoryId": 24,
        "categoryName": "配饰",
        "parentId": 3
    },
    {
        "categoryId": 26,
        "categoryName": "童车童床",
        "parentId": 4
    },
    {
        "categoryId": 27,
        "categoryName": "童装",
        "parentId": 4
    },
    {
        "categoryId": 28,
        "categoryName": "高跟鞋",
        "parentId": 10
    },
    {
        "categoryId": 29,
        "categoryName": "女士单鞋",
        "parentId": 10
    },
    {
        "categoryId": 39,
        "categoryName": "光学眼镜",
        "parentId": 7
    },
    {
        "categoryId": 45,
        "categoryName": "卧室家具",
        "parentId": 8
    },
    {
        "categoryId": 46,
        "categoryName": "客厅家具",
        "parentId": 8
    },
    {
        "categoryId": 47,
        "categoryName": "书房家具",
        "parentId": 8
    },
    {
        "categoryId": 48,
        "categoryName": "烹饪锅具",
        "parentId": 52
    },
    {
        "categoryId": 49,
        "categoryName": "水具",
        "parentId": 52
    },
    {
        "categoryId": 50,
        "categoryName": "餐厅家具",
        "parentId": 8
    },
    {
        "categoryId": 51,
        "categoryName": "储物家具",
        "parentId": 8
    },
    {
        "categoryId": 52,
        "categoryName": "厨具",
        "parentId": 0
    },
    {
        "categoryId": 53,
        "categoryName": "儿童房家具",
        "parentId": 8
    },
    {
        "categoryId": 62,
        "categoryName": "厨房卫浴",
        "parentId": 1
    },
    {
        "categoryId": 63,
        "categoryName": "灯具",
        "parentId": 1
    },
    {
        "categoryId": 70,
        "categoryName": "美妆个护",
        "parentId": 0
    },
    {
        "categoryId": 71,
        "categoryName": "家纺",
        "parentId": 0
    },
    {
        "categoryId": 82,
        "categoryName": "抹胸/打底",
        "parentId": 21
    },
    {
        "categoryId": 87,
        "categoryName": "手套",
        "parentId": 24
    },
    {
        "categoryId": 93,
        "categoryName": "女士休闲鞋",
        "parentId": 10
    },
    {
        "categoryId": 94,
        "categoryName": "女士凉鞋",
        "parentId": 10
    },
    {
        "categoryId": 95,
        "categoryName": "女靴",
        "parentId": 10
    },
    {
        "categoryId": 97,
        "categoryName": "女士雪地靴",
        "parentId": 10
    },
    {
        "categoryId": 104,
        "categoryName": "篮球鞋",
        "parentId": 14
    },
    {
        "categoryId": 105,
        "categoryName": "跑步鞋",
        "parentId": 14
    },
    {
        "categoryId": 108,
        "categoryName": "训练鞋",
        "parentId": 14
    },
    {
        "categoryId": 109,
        "categoryName": "运动板鞋",
        "parentId": 14
    },
    {
        "categoryId": 111,
        "categoryName": "男士休闲鞋",
        "parentId": 15
    },
    {
        "categoryId": 114,
        "categoryName": "男士板鞋",
        "parentId": 15
    },
    {
        "categoryId": 115,
        "categoryName": "男士正装鞋",
        "parentId": 15
    },
    {
        "categoryId": 129,
        "categoryName": "吊带/背心",
        "parentId": 21
    },
    {
        "categoryId": 130,
        "categoryName": "塑身美体",
        "parentId": 21
    },
    {
        "categoryId": 131,
        "categoryName": "女式内裤",
        "parentId": 21
    },
    {
        "categoryId": 132,
        "categoryName": "保暖内衣",
        "parentId": 21
    },
    {
        "categoryId": 133,
        "categoryName": "泳衣",
        "parentId": 21
    },
    {
        "categoryId": 134,
        "categoryName": "文胸套装",
        "parentId": 21
    },
    {
        "categoryId": 145,
        "categoryName": "帽子",
        "parentId": 24
    },
    {
        "categoryId": 146,
        "categoryName": "女士丝巾/围巾/披肩",
        "parentId": 24
    },
    {
        "categoryId": 147,
        "categoryName": "男士丝巾/围巾",
        "parentId": 24
    },
    {
        "categoryId": 148,
        "categoryName": "男士腰带",
        "parentId": 24
    },
    {
        "categoryId": 156,
        "categoryName": "儿童自行车",
        "parentId": 26
    },
    {
        "categoryId": 157,
        "categoryName": "婴儿推车",
        "parentId": 26
    },
    {
        "categoryId": 158,
        "categoryName": "婴儿床",
        "parentId": 26
    },
    {
        "categoryId": 159,
        "categoryName": "电动车",
        "parentId": 26
    },
    {
        "categoryId": 160,
        "categoryName": "学步车",
        "parentId": 26
    },
    {
        "categoryId": 162,
        "categoryName": "裤子",
        "parentId": 27
    },
    {
        "categoryId": 163,
        "categoryName": "羽绒服/棉服",
        "parentId": 27
    },
    {
        "categoryId": 164,
        "categoryName": "内衣内裤套装",
        "parentId": 27
    },
    {
        "categoryId": 165,
        "categoryName": "外套/夹克/大衣",
        "parentId": 27
    },
    {
        "categoryId": 166,
        "categoryName": "T恤",
        "parentId": 27
    },
    {
        "categoryId": 217,
        "categoryName": "光学太阳镜",
        "parentId": 39
    },
    {
        "categoryId": 218,
        "categoryName": "儿童太阳镜",
        "parentId": 39
    },
    {
        "categoryId": 219,
        "categoryName": "平光太阳镜",
        "parentId": 39
    },
    {
        "categoryId": 220,
        "categoryName": "功能眼镜",
        "parentId": 39
    },
    {
        "categoryId": 265,
        "categoryName": "床",
        "parentId": 45
    },
    {
        "categoryId": 266,
        "categoryName": "床垫",
        "parentId": 45
    },
    {
        "categoryId": 267,
        "categoryName": "床头柜",
        "parentId": 45
    },
    {
        "categoryId": 268,
        "categoryName": "沙发",
        "parentId": 46
    },
    {
        "categoryId": 269,
        "categoryName": "沙发床",
        "parentId": 46
    },
    {
        "categoryId": 270,
        "categoryName": "边桌/茶几",
        "parentId": 46
    },
    {
        "categoryId": 271,
        "categoryName": "书柜/书架",
        "parentId": 47
    },
    {
        "categoryId": 272,
        "categoryName": "电脑椅",
        "parentId": 47
    },
    {
        "categoryId": 273,
        "categoryName": "书桌",
        "parentId": 47
    },
    {
        "categoryId": 274,
        "categoryName": "电脑桌",
        "parentId": 47
    },
    {
        "categoryId": 275,
        "categoryName": "功能椅",
        "parentId": 47
    },
    {
        "categoryId": 276,
        "categoryName": "餐桌",
        "parentId": 50
    },
    {
        "categoryId": 278,
        "categoryName": "餐边柜",
        "parentId": 50
    },
    {
        "categoryId": 279,
        "categoryName": "餐椅/吧台椅",
        "parentId": 50
    },
    {
        "categoryId": 280,
        "categoryName": "酒柜",
        "parentId": 50
    },
    {
        "categoryId": 281,
        "categoryName": "鞋架/衣帽架",
        "parentId": 51
    },
    {
        "categoryId": 282,
        "categoryName": "储物/收纳用品",
        "parentId": 51
    },
    {
        "categoryId": 283,
        "categoryName": "墙面搁架",
        "parentId": 51
    },
    {
        "categoryId": 284,
        "categoryName": "儿童床",
        "parentId": 53
    },
    {
        "categoryId": 285,
        "categoryName": "儿童床垫",
        "parentId": 53
    },
    {
        "categoryId": 286,
        "categoryName": "儿童衣柜",
        "parentId": 53
    },
    {
        "categoryId": 287,
        "categoryName": "儿童桌椅",
        "parentId": 53
    },
    {
        "categoryId": 288,
        "categoryName": "炒锅",
        "parentId": 48
    },
    {
        "categoryId": 289,
        "categoryName": "煎锅/平底锅",
        "parentId": 48
    },
    {
        "categoryId": 290,
        "categoryName": "压力锅/高压锅",
        "parentId": 48
    },
    {
        "categoryId": 291,
        "categoryName": "蒸锅",
        "parentId": 48
    },
    {
        "categoryId": 292,
        "categoryName": "汤锅",
        "parentId": 48
    },
    {
        "categoryId": 295,
        "categoryName": "保温壶",
        "parentId": 49
    },
    {
        "categoryId": 296,
        "categoryName": "保温杯",
        "parentId": 49
    },
    {
        "categoryId": 299,
        "categoryName": "淋浴花洒",
        "parentId": 62
    },
    {
        "categoryId": 300,
        "categoryName": "厨卫五金/挂件",
        "parentId": 62
    },
    {
        "categoryId": 301,
        "categoryName": "龙头",
        "parentId": 62
    },
    {
        "categoryId": 302,
        "categoryName": "台灯",
        "parentId": 63
    },
    {
        "categoryId": 303,
        "categoryName": "光学眼镜",
        "parentId": 39
    },
    {
        "categoryId": 304,
        "categoryName": "儿童光学眼镜",
        "parentId": 39
    },
    {
        "categoryId": 305,
        "categoryName": "运动/户外眼镜",
        "parentId": 39
    },
    {
        "categoryId": 316,
        "categoryName": "箱包",
        "parentId": 0
    },
    {
        "categoryId": 322,
        "categoryName": "男装",
        "parentId": 3
    },
    {
        "categoryId": 323,
        "categoryName": "女装",
        "parentId": 3
    },
    {
        "categoryId": 402,
        "categoryName": "钟表",
        "parentId": 3
    },
    {
        "categoryId": 1002,
        "categoryName": "女士工装鞋",
        "parentId": 10
    },
    {
        "categoryId": 1302,
        "categoryName": "童鞋休闲鞋",
        "parentId": 13
    },
    {
        "categoryId": 1501,
        "categoryName": "男士拖鞋/人字拖",
        "parentId": 15
    },
    {
        "categoryId": 1502,
        "categoryName": "男士凉鞋/沙滩鞋",
        "parentId": 15
    },
    {
        "categoryId": 1503,
        "categoryName": "帆布鞋",
        "parentId": 15
    },
    {
        "categoryId": 1504,
        "categoryName": "男士雪地靴",
        "parentId": 15
    },
    {
        "categoryId": 1902,
        "categoryName": "户外服饰",
        "parentId": 19
    },
    {
        "categoryId": 2101,
        "categoryName": "文胸",
        "parentId": 21
    },
    {
        "categoryId": 2103,
        "categoryName": "睡衣",
        "parentId": 21
    },
    {
        "categoryId": 7001,
        "categoryName": "面部护理",
        "parentId": 70
    },
    {
        "categoryId": 7002,
        "categoryName": "身体护理",
        "parentId": 70
    },
    {
        "categoryId": 7101,
        "categoryName": "床品套件",
        "parentId": 71
    },
    {
        "categoryId": 7102,
        "categoryName": "被子被芯",
        "parentId": 71
    },
    {
        "categoryId": 7103,
        "categoryName": "枕头枕芯",
        "parentId": 71
    },
    {
        "categoryId": 7104,
        "categoryName": "布艺软饰",
        "parentId": 71
    },
    {
        "categoryId": 9000,
        "categoryName": "3C数码",
        "parentId": 0
    },
    {
        "categoryId": 9001,
        "categoryName": "家用电器",
        "parentId": 0
    },
    {
        "categoryId": 9002,
        "categoryName": "汽车用品",
        "parentId": 0
    },
    {
        "categoryId": 31601,
        "categoryName": "功能箱包",
        "parentId": 316
    },
    {
        "categoryId": 31602,
        "categoryName": "男包",
        "parentId": 316
    },
    {
        "categoryId": 32201,
        "categoryName": "Polo衫",
        "parentId": 322
    },
    {
        "categoryId": 32202,
        "categoryName": "T恤",
        "parentId": 322
    },
    {
        "categoryId": 32203,
        "categoryName": "夹克",
        "parentId": 322
    },
    {
        "categoryId": 32204,
        "categoryName": "西服",
        "parentId": 322
    },
    {
        "categoryId": 32205,
        "categoryName": "针织衫/毛衣",
        "parentId": 322
    },
    {
        "categoryId": 32206,
        "categoryName": "长裤",
        "parentId": 322
    },
    {
        "categoryId": 32301,
        "categoryName": "针织衫/毛衣",
        "parentId": 323
    },
    {
        "categoryId": 32302,
        "categoryName": "POLO衫",
        "parentId": 323
    },
    {
        "categoryId": 32303,
        "categoryName": "大衣",
        "parentId": 323
    },
    {
        "categoryId": 40201,
        "categoryName": "石英手表",
        "parentId": 402
    },
    {
        "categoryId": 40202,
        "categoryName": "机械手表",
        "parentId": 402
    },
    {
        "categoryId": 190201,
        "categoryName": "冲锋衣",
        "parentId": 1902
    },
    {
        "categoryId": 190202,
        "categoryName": "户外风衣",
        "parentId": 1902
    },
    {
        "categoryId": 190203,
        "categoryName": "抓绒衣",
        "parentId": 1902
    },
    {
        "categoryId": 190204,
        "categoryName": "软壳衣",
        "parentId": 1902
    },
    {
        "categoryId": 190205,
        "categoryName": "速干衣",
        "parentId": 1902
    },
    {
        "categoryId": 190206,
        "categoryName": "男羽绒服",
        "parentId": 1902
    },
    {
        "categoryId": 190207,
        "categoryName": "棉服",
        "parentId": 1902
    },
    {
        "categoryId": 190208,
        "categoryName": "功能内衣裤",
        "parentId": 1902
    },
    {
        "categoryId": 190209,
        "categoryName": "滑雪服",
        "parentId": 1902
    },
    {
        "categoryId": 190210,
        "categoryName": "休闲衣",
        "parentId": 1902
    },
    {
        "categoryId": 190211,
        "categoryName": "T恤",
        "parentId": 1902
    },
    {
        "categoryId": 190212,
        "categoryName": "户外袜",
        "parentId": 1902
    },
    {
        "categoryId": 210001,
        "categoryName": "男士内裤",
        "parentId": 21
    },
    {
        "categoryId": 700101,
        "categoryName": "剃须用品",
        "parentId": 7001
    },
    {
        "categoryId": 700102,
        "categoryName": "护肤",
        "parentId": 7001
    },
    {
        "categoryId": 700103,
        "categoryName": "面膜",
        "parentId": 7001
    },
    {
        "categoryId": 700201,
        "categoryName": "美胸",
        "parentId": 7002
    },
    {
        "categoryId": 710101,
        "categoryName": "多件套",
        "parentId": 7101
    },
    {
        "categoryId": 710102,
        "categoryName": "四件套",
        "parentId": 7101
    },
    {
        "categoryId": 710201,
        "categoryName": "羽绒被",
        "parentId": 7102
    },
    {
        "categoryId": 710301,
        "categoryName": "羽绒枕",
        "parentId": 7103
    },
    {
        "categoryId": 710402,
        "categoryName": "浴衣/浴袍",
        "parentId": 7104
    },
    {
        "categoryId": 800101,
        "categoryName": "装饰材料",
        "parentId": 1
    },
    {
        "categoryId": 800102,
        "categoryName": "五金工具",
        "parentId": 1
    },
    {
        "categoryId": 800103,
        "categoryName": "家装软饰",
        "parentId": 1
    },
    {
        "categoryId": 800104,
        "categoryName": "生活日用",
        "parentId": 1
    },
    {
        "categoryId": 800105,
        "categoryName": "电工电料",
        "parentId": 1
    },
    {
        "categoryId": 800400,
        "categoryName": "童鞋",
        "parentId": 4
    },
    {
        "categoryId": 800401,
        "categoryName": "孕产用品",
        "parentId": 4
    },
    {
        "categoryId": 800402,
        "categoryName": "婴儿服饰寝具",
        "parentId": 4
    },
    {
        "categoryId": 800403,
        "categoryName": "玩具",
        "parentId": 4
    },
    {
        "categoryId": 800404,
        "categoryName": "尿裤湿巾",
        "parentId": 4
    },
    {
        "categoryId": 800405,
        "categoryName": "喂养用品",
        "parentId": 4
    },
    {
        "categoryId": 801901,
        "categoryName": "运动服饰",
        "parentId": 19
    },
    {
        "categoryId": 801902,
        "categoryName": "户外装备",
        "parentId": 19
    },
    {
        "categoryId": 801903,
        "categoryName": "运动装备",
        "parentId": 19
    },
    {
        "categoryId": 805200,
        "categoryName": "刀剪菜板",
        "parentId": 52
    },
    {
        "categoryId": 805201,
        "categoryName": "餐具",
        "parentId": 52
    },
    {
        "categoryId": 805202,
        "categoryName": "厨房配件",
        "parentId": 52
    },
    {
        "categoryId": 807000,
        "categoryName": "口腔护理",
        "parentId": 70
    },
    {
        "categoryId": 807002,
        "categoryName": "洗发护发",
        "parentId": 70
    },
    {
        "categoryId": 807003,
        "categoryName": "香水彩妆",
        "parentId": 70
    },
    {
        "categoryId": 807004,
        "categoryName": "家庭清洁/个护用品",
        "parentId": 70
    },
    {
        "categoryId": 807005,
        "categoryName": "男士护肤",
        "parentId": 70
    },
    {
        "categoryId": 831600,
        "categoryName": "女包",
        "parentId": 316
    },
    {
        "categoryId": 900000,
        "categoryName": "手机/平板配件",
        "parentId": 9000
    },
    {
        "categoryId": 900001,
        "categoryName": "影音娱乐",
        "parentId": 9000
    },
    {
        "categoryId": 900100,
        "categoryName": "厨房电器",
        "parentId": 9001
    },
    {
        "categoryId": 900101,
        "categoryName": "生活电器",
        "parentId": 9001
    },
    {
        "categoryId": 900102,
        "categoryName": "个护健康",
        "parentId": 9001
    },
    {
        "categoryId": 900200,
        "categoryName": "汽车装饰",
        "parentId": 9002
    },
    {
        "categoryId": 900201,
        "categoryName": "车载电器",
        "parentId": 9002
    },
    {
        "categoryId": 3160101,
        "categoryName": "拉杆箱",
        "parentId": 31601
    },
    {
        "categoryId": 3160201,
        "categoryName": "双肩包",
        "parentId": 31602
    },
    {
        "categoryId": 6000003,
        "categoryName": "烤盘",
        "parentId": 900100
    },
    {
        "categoryId": 6000004,
        "categoryName": "生鲜水果",
        "parentId": 0
    },
    {
        "categoryId": 6000007,
        "categoryName": "海鲜水产",
        "parentId": 6000004
    },
    {
        "categoryId": 6000008,
        "categoryName": "肉类",
        "parentId": 6000004
    },
    {
        "categoryId": 6000009,
        "categoryName": "鱼类",
        "parentId": 6000007
    },
    {
        "categoryId": 6000010,
        "categoryName": "牛排",
        "parentId": 6000008
    },
    {
        "categoryId": 6000011,
        "categoryName": "女性护理",
        "parentId": 70
    },
    {
        "categoryId": 6000012,
        "categoryName": "卫生巾",
        "parentId": 6000011
    },
    {
        "categoryId": 6000013,
        "categoryName": "卫生护垫",
        "parentId": 6000011
    },
    {
        "categoryId": 6000016,
        "categoryName": "婴儿湿巾",
        "parentId": 800404
    },
    {
        "categoryId": 6000017,
        "categoryName": "拉拉裤",
        "parentId": 800404
    },
    {
        "categoryId": 6000018,
        "categoryName": "成人尿裤",
        "parentId": 800404
    },
    {
        "categoryId": 6000019,
        "categoryName": "食品饮料",
        "parentId": 0
    },
    {
        "categoryId": 6000020,
        "categoryName": "调味品",
        "parentId": 6000019
    },
    {
        "categoryId": 6000022,
        "categoryName": "休闲食品",
        "parentId": 6000019
    },
    {
        "categoryId": 6000023,
        "categoryName": "坚果炒货",
        "parentId": 6000022
    },
    {
        "categoryId": 6000024,
        "categoryName": "蛋类",
        "parentId": 6000004
    },
    {
        "categoryId": 6000025,
        "categoryName": "乌鸡蛋",
        "parentId": 6000024
    },
    {
        "categoryId": 6000028,
        "categoryName": "医疗保健",
        "parentId": 0
    },
    {
        "categoryId": 6000029,
        "categoryName": "保健器械",
        "parentId": 6000028
    },
    {
        "categoryId": 6000032,
        "categoryName": "护理护具",
        "parentId": 6000028
    },
    {
        "categoryId": 6000033,
        "categoryName": "口罩",
        "parentId": 6000032
    },
    {
        "categoryId": 6000034,
        "categoryName": "儿童口罩",
        "parentId": 6000032
    },
    {
        "categoryId": 6000035,
        "categoryName": "洗手液",
        "parentId": 7002
    },
    {
        "categoryId": 6000038,
        "categoryName": "衣物清洁剂/护理剂",
        "parentId": 807004
    },
    {
        "categoryId": 6000039,
        "categoryName": "手机支架",
        "parentId": 900000
    },
    {
        "categoryId": 6000046,
        "categoryName": "虾类",
        "parentId": 6000007
    },
    {
        "categoryId": 6000047,
        "categoryName": "鱼类制品",
        "parentId": 6000007
    },
    {
        "categoryId": 6000048,
        "categoryName": "蟹类",
        "parentId": 6000007
    },
    {
        "categoryId": 6000049,
        "categoryName": "贝类",
        "parentId": 6000007
    },
    {
        "categoryId": 6000050,
        "categoryName": "女羽绒服",
        "parentId": 1902
    },
    {
        "categoryId": 6000051,
        "categoryName": "电脑办公",
        "parentId": 0
    },
    {
        "categoryId": 6000052,
        "categoryName": "外设产品",
        "parentId": 6000051
    },
    {
        "categoryId": 6000053,
        "categoryName": "办公设备",
        "parentId": 6000051
    },
    {
        "categoryId": 6000054,
        "categoryName": "投影机",
        "parentId": 6000053
    },
    {
        "categoryId": 6000055,
        "categoryName": "文具耗材",
        "parentId": 6000051
    },
    {
        "categoryId": 6000056,
        "categoryName": "笔类",
        "parentId": 6000055
    },
    {
        "categoryId": 6000057,
        "categoryName": "本册/便签",
        "parentId": 6000055
    },
    {
        "categoryId": 6000058,
        "categoryName": "移动硬盘",
        "parentId": 6000052
    },
    {
        "categoryId": 6000059,
        "categoryName": "U盘",
        "parentId": 6000052
    },
    {
        "categoryId": 6000060,
        "categoryName": "鼠标",
        "parentId": 6000052
    },
    {
        "categoryId": 6000061,
        "categoryName": "键盘",
        "parentId": 6000052
    },
    {
        "categoryId": 6000062,
        "categoryName": "鼠标垫",
        "parentId": 6000052
    },
    {
        "categoryId": 6000063,
        "categoryName": "摄像头",
        "parentId": 6000052
    },
    {
        "categoryId": 6000064,
        "categoryName": "家用投影机",
        "parentId": 900001
    },
    {
        "categoryId": 6000067,
        "categoryName": "座套",
        "parentId": 900200
    },
    {
        "categoryId": 6000068,
        "categoryName": "扫地机器人",
        "parentId": 900101
    },
    {
        "categoryId": 6000069,
        "categoryName": "电蒸锅",
        "parentId": 900100
    },
    {
        "categoryId": 6000070,
        "categoryName": "挂烫机/熨斗",
        "parentId": 900101
    },
    {
        "categoryId": 6000071,
        "categoryName": "手机耳机",
        "parentId": 900000
    },
    {
        "categoryId": 6000073,
        "categoryName": "帆布袋",
        "parentId": 7104
    },
    {
        "categoryId": 6000078,
        "categoryName": "美容清洗",
        "parentId": 9002
    },
    {
        "categoryId": 6000081,
        "categoryName": "车用掸子",
        "parentId": 6000078
    },
    {
        "categoryId": 6000083,
        "categoryName": "清洁剂",
        "parentId": 6000078
    },
    {
        "categoryId": 6000084,
        "categoryName": "洗车毛巾",
        "parentId": 6000078
    },
    {
        "categoryId": 6000086,
        "categoryName": "清洁工具",
        "parentId": 800104
    },
    {
        "categoryId": 6000089,
        "categoryName": "电动晾衣架",
        "parentId": 900101
    },
    {
        "categoryId": 6000090,
        "categoryName": "炖锅/焖烧锅",
        "parentId": 48
    },
    {
        "categoryId": 6000093,
        "categoryName": "车载吸尘器",
        "parentId": 900201
    },
    {
        "categoryId": 6000096,
        "categoryName": "维修保养",
        "parentId": 9002
    },
    {
        "categoryId": 6000098,
        "categoryName": "血压计",
        "parentId": 6000029
    },
    {
        "categoryId": 6000099,
        "categoryName": "雾化器",
        "parentId": 6000029
    },
    {
        "categoryId": 6000100,
        "categoryName": "儿童洗护",
        "parentId": 7002
    },
    {
        "categoryId": 6000101,
        "categoryName": "儿童护肤",
        "parentId": 7002
    },
    {
        "categoryId": 6000102,
        "categoryName": "特殊商品",
        "parentId": 0
    },
    {
        "categoryId": 6000103,
        "categoryName": "美妆个护",
        "parentId": 6000102
    },
    {
        "categoryId": 6000104,
        "categoryName": "面部护理/精华",
        "parentId": 6000103
    },
    {
        "categoryId": 6000105,
        "categoryName": "地席/防潮垫",
        "parentId": 801902
    },
    {
        "categoryId": 6000107,
        "categoryName": "睡袋/吊床",
        "parentId": 801902
    },
    {
        "categoryId": 6000108,
        "categoryName": "帐篷",
        "parentId": 801902
    },
    {
        "categoryId": 6000109,
        "categoryName": "美容仪",
        "parentId": 900102
    },
    {
        "categoryId": 6000111,
        "categoryName": "大家电",
        "parentId": 9001
    },
    {
        "categoryId": 6000112,
        "categoryName": "平板电视",
        "parentId": 6000111
    },
    {
        "categoryId": 6000113,
        "categoryName": "电吹风",
        "parentId": 900102
    },
    {
        "categoryId": 6000114,
        "categoryName": "电动剃须刀",
        "parentId": 900102
    },
    {
        "categoryId": 6000117,
        "categoryName": "蓝牙耳机",
        "parentId": 900000
    },
    {
        "categoryId": 6000118,
        "categoryName": "洗车工具",
        "parentId": 6000078
    },
    {
        "categoryId": 6000120,
        "categoryName": "面部护理/面膜",
        "parentId": 6000103
    },
    {
        "categoryId": 6000121,
        "categoryName": "面部护理/眼部护理",
        "parentId": 6000103
    },
    {
        "categoryId": 6000122,
        "categoryName": "香水彩妆/口红唇膏唇彩",
        "parentId": 6000103
    },
    {
        "categoryId": 6000123,
        "categoryName": "香水彩妆/底妆",
        "parentId": 6000103
    },
    {
        "categoryId": 6000126,
        "categoryName": "猪肉/猪排",
        "parentId": 6000008
    },
    {
        "categoryId": 6000127,
        "categoryName": "牛肉",
        "parentId": 6000008
    },
    {
        "categoryId": 6000128,
        "categoryName": "饮料冲调",
        "parentId": 6000019
    },
    {
        "categoryId": 6000129,
        "categoryName": "茗茶",
        "parentId": 6000019
    },
    {
        "categoryId": 6000130,
        "categoryName": "蜂蜜/柚子茶",
        "parentId": 6000128
    },
    {
        "categoryId": 6000131,
        "categoryName": "龙井",
        "parentId": 6000129
    },
    {
        "categoryId": 6000132,
        "categoryName": "羊肉类",
        "parentId": 6000008
    },
    {
        "categoryId": 6000133,
        "categoryName": "鸡肉",
        "parentId": 6000008
    },
    {
        "categoryId": 6000141,
        "categoryName": "电子秤",
        "parentId": 900100
    },
    {
        "categoryId": 6000142,
        "categoryName": "肉干肉脯",
        "parentId": 6000022
    },
    {
        "categoryId": 6000143,
        "categoryName": "膨化食品",
        "parentId": 6000022
    },
    {
        "categoryId": 6000144,
        "categoryName": "腊味制品",
        "parentId": 6000022
    },
    {
        "categoryId": 6000145,
        "categoryName": "参类",
        "parentId": 6000007
    },
    {
        "categoryId": 6000147,
        "categoryName": "绿茶",
        "parentId": 6000129
    },
    {
        "categoryId": 6000148,
        "categoryName": "白茶",
        "parentId": 6000129
    },
    {
        "categoryId": 6000149,
        "categoryName": "红茶",
        "parentId": 6000129
    },
    {
        "categoryId": 6000150,
        "categoryName": "黑茶",
        "parentId": 6000129
    },
    {
        "categoryId": 6000151,
        "categoryName": "普洱",
        "parentId": 6000129
    },
    {
        "categoryId": 6000157,
        "categoryName": "体温计",
        "parentId": 6000029
    },
    {
        "categoryId": 6000159,
        "categoryName": "阳台/户外家具",
        "parentId": 8
    },
    {
        "categoryId": 6000160,
        "categoryName": "户外桌椅凳",
        "parentId": 6000159
    },
    {
        "categoryId": 6000161,
        "categoryName": "折叠床",
        "parentId": 6000159
    },
    {
        "categoryId": 6000164,
        "categoryName": "数码配件",
        "parentId": 9000
    },
    {
        "categoryId": 6000166,
        "categoryName": "数码支架",
        "parentId": 6000164
    },
    {
        "categoryId": 6000167,
        "categoryName": "睡袋",
        "parentId": 7101
    },
    {
        "categoryId": 6000168,
        "categoryName": "T区护理",
        "parentId": 7001
    },
    {
        "categoryId": 6000169,
        "categoryName": "面部按摩霜",
        "parentId": 7001
    },
    {
        "categoryId": 6000170,
        "categoryName": "腮红/胭脂",
        "parentId": 807003
    },
    {
        "categoryId": 6000171,
        "categoryName": "运动连身裙",
        "parentId": 801901
    },
    {
        "categoryId": 6000173,
        "categoryName": "胸包/腰包",
        "parentId": 31602
    },
    {
        "categoryId": 6000174,
        "categoryName": "手提包",
        "parentId": 31602
    },
    {
        "categoryId": 6000179,
        "categoryName": "儿童文具",
        "parentId": 800403
    },
    {
        "categoryId": 6000180,
        "categoryName": "滑板车",
        "parentId": 26
    },
    {
        "categoryId": 6000182,
        "categoryName": "孕妇袜",
        "parentId": 800401
    },
    {
        "categoryId": 6000184,
        "categoryName": "产妇卫生巾/护垫",
        "parentId": 800401
    },
    {
        "categoryId": 6000186,
        "categoryName": "防溢乳垫",
        "parentId": 800401
    },
    {
        "categoryId": 6000189,
        "categoryName": "凉鞋",
        "parentId": 800400
    },
    {
        "categoryId": 6000192,
        "categoryName": "宠物用品",
        "parentId": 0
    },
    {
        "categoryId": 6000193,
        "categoryName": "宠物日用",
        "parentId": 6000192
    },
    {
        "categoryId": 6000194,
        "categoryName": "宠物食品",
        "parentId": 6000192
    },
    {
        "categoryId": 6000195,
        "categoryName": "宠物玩具",
        "parentId": 6000192
    },
    {
        "categoryId": 6000199,
        "categoryName": "宠物出行",
        "parentId": 6000192
    },
    {
        "categoryId": 6000204,
        "categoryName": "牵引带",
        "parentId": 6000193
    },
    {
        "categoryId": 6000207,
        "categoryName": "宠物清洁",
        "parentId": 6000193
    },
    {
        "categoryId": 6000208,
        "categoryName": "剃须刀",
        "parentId": 7001
    },
    {
        "categoryId": 6000209,
        "categoryName": "刮毛刀",
        "parentId": 7002
    },
    {
        "categoryId": 6000210,
        "categoryName": "运动内衣",
        "parentId": 801901
    },
    {
        "categoryId": 6000211,
        "categoryName": "咖啡粉",
        "parentId": 6000128
    },
    {
        "categoryId": 6000214,
        "categoryName": "安全防护",
        "parentId": 800403
    },
    {
        "categoryId": 6000215,
        "categoryName": "外穿吊带",
        "parentId": 323
    },
    {
        "categoryId": 6000217,
        "categoryName": "职业套装",
        "parentId": 323
    },
    {
        "categoryId": 6000218,
        "categoryName": "正装裤",
        "parentId": 323
    },
    {
        "categoryId": 6000219,
        "categoryName": "休闲裤",
        "parentId": 323
    },
    {
        "categoryId": 6000220,
        "categoryName": "打底裤",
        "parentId": 323
    },
    {
        "categoryId": 6000222,
        "categoryName": "加湿器",
        "parentId": 900101
    },
    {
        "categoryId": 6000223,
        "categoryName": "养生壶",
        "parentId": 900101
    },
    {
        "categoryId": 6000224,
        "categoryName": "电暖气",
        "parentId": 900101
    },
    {
        "categoryId": 6000225,
        "categoryName": "净水器",
        "parentId": 900101
    },
    {
        "categoryId": 6000226,
        "categoryName": "豆浆机",
        "parentId": 900100
    },
    {
        "categoryId": 6000227,
        "categoryName": "微波炉",
        "parentId": 900100
    },
    {
        "categoryId": 6000228,
        "categoryName": "电饭煲",
        "parentId": 900100
    },
    {
        "categoryId": 6000229,
        "categoryName": "多士炉",
        "parentId": 900100
    },
    {
        "categoryId": 6000230,
        "categoryName": "蒸蛋器",
        "parentId": 900100
    },
    {
        "categoryId": 6000231,
        "categoryName": "电饼铛",
        "parentId": 900100
    },
    {
        "categoryId": 6000232,
        "categoryName": "车载香氛",
        "parentId": 900200
    },
    {
        "categoryId": 6000233,
        "categoryName": "临时停车牌",
        "parentId": 900200
    },
    {
        "categoryId": 6000234,
        "categoryName": "男士内衣",
        "parentId": 21
    },
    {
        "categoryId": 6000235,
        "categoryName": "键鼠套装",
        "parentId": 6000052
    },
    {
        "categoryId": 6000236,
        "categoryName": "插线板/插座",
        "parentId": 6000052
    },
    {
        "categoryId": 6000237,
        "categoryName": "眼膜",
        "parentId": 7001
    },
    {
        "categoryId": 6000238,
        "categoryName": "方巾/头巾",
        "parentId": 24
    },
    {
        "categoryId": 6000239,
        "categoryName": "料理机",
        "parentId": 900100
    },
    {
        "categoryId": 6000240,
        "categoryName": "猫狗窝",
        "parentId": 6000193
    },
    {
        "categoryId": 6000241,
        "categoryName": "婴儿凉席",
        "parentId": 7101
    },
    {
        "categoryId": 6000242,
        "categoryName": "破壁机",
        "parentId": 900100
    },
    {
        "categoryId": 6000246,
        "categoryName": "调味品",
        "parentId": 6000020
    },
    {
        "categoryId": 6000249,
        "categoryName": "冲调粉",
        "parentId": 6000128
    },
    {
        "categoryId": 6000250,
        "categoryName": "汤类",
        "parentId": 6000128
    },
    {
        "categoryId": 6000251,
        "categoryName": "正餐",
        "parentId": 6000019
    },
    {
        "categoryId": 6000252,
        "categoryName": "方便主食/面",
        "parentId": 6000251
    },
    {
        "categoryId": 6000253,
        "categoryName": "速食汤/速食粥",
        "parentId": 6000251
    },
    {
        "categoryId": 6000254,
        "categoryName": "保暖贴/暖手贴",
        "parentId": 800104
    },
    {
        "categoryId": 6000256,
        "categoryName": "乌龙茶",
        "parentId": 6000129
    },
    {
        "categoryId": 6000258,
        "categoryName": "糖果/巧克力",
        "parentId": 6000022
    },
    {
        "categoryId": 6000259,
        "categoryName": "饼干蛋糕",
        "parentId": 6000022
    },
    {
        "categoryId": 6000260,
        "categoryName": "蜜饯果干",
        "parentId": 6000022
    },
    {
        "categoryId": 6000261,
        "categoryName": "摄影镜头",
        "parentId": 900000
    },
    {
        "categoryId": 6000262,
        "categoryName": "望远镜",
        "parentId": 801902
    },
    {
        "categoryId": 6000263,
        "categoryName": "咖啡豆",
        "parentId": 6000128
    },
    {
        "categoryId": 6000265,
        "categoryName": "足球",
        "parentId": 801903
    },
    {
        "categoryId": 6000266,
        "categoryName": "篮球",
        "parentId": 801903
    },
    {
        "categoryId": 6000271,
        "categoryName": "电烤锅",
        "parentId": 900100
    },
    {
        "categoryId": 6000272,
        "categoryName": "绞肉机",
        "parentId": 900100
    },
    {
        "categoryId": 6000273,
        "categoryName": "电陶炉",
        "parentId": 900100
    },
    {
        "categoryId": 6000274,
        "categoryName": "抽真空机",
        "parentId": 900101
    },
    {
        "categoryId": 6000279,
        "categoryName": "花草茶",
        "parentId": 6000129
    },
    {
        "categoryId": 6000280,
        "categoryName": "梨膏",
        "parentId": 6000128
    },
    {
        "categoryId": 6000281,
        "categoryName": "果汁饮料",
        "parentId": 6000128
    },
    {
        "categoryId": 6000282,
        "categoryName": "儿童写字板",
        "parentId": 6000164
    },
    {
        "categoryId": 6000283,
        "categoryName": "商务写字板",
        "parentId": 6000164
    },
    {
        "categoryId": 6000284,
        "categoryName": "方便肉/菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000286,
        "categoryName": "茗茶",
        "parentId": 6000102
    },
    {
        "categoryId": 6000287,
        "categoryName": "花茶",
        "parentId": 6000286
    },
    {
        "categoryId": 6000288,
        "categoryName": "食品饮料",
        "parentId": 6000102
    },
    {
        "categoryId": 6000289,
        "categoryName": "巧克力咖啡豆",
        "parentId": 6000288
    },
    {
        "categoryId": 6000290,
        "categoryName": "庭院灯/户外灯",
        "parentId": 63
    },
    {
        "categoryId": 6000291,
        "categoryName": "应急灯/手电",
        "parentId": 63
    },
    {
        "categoryId": 6000292,
        "categoryName": "氛围照明/小夜灯",
        "parentId": 63
    },
    {
        "categoryId": 6000293,
        "categoryName": "水晶灯",
        "parentId": 63
    },
    {
        "categoryId": 6000294,
        "categoryName": "电热毯",
        "parentId": 7104
    },
    {
        "categoryId": 6000295,
        "categoryName": "水果茶",
        "parentId": 6000129
    },
    {
        "categoryId": 6000296,
        "categoryName": "滋补品",
        "parentId": 6000128
    },
    {
        "categoryId": 6000297,
        "categoryName": "垃圾处理器",
        "parentId": 62
    },
    {
        "categoryId": 6000298,
        "categoryName": "翻译机",
        "parentId": 6000164
    },
    {
        "categoryId": 6000299,
        "categoryName": "川菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000301,
        "categoryName": "除湿机",
        "parentId": 900101
    },
    {
        "categoryId": 6000302,
        "categoryName": "体脂秤",
        "parentId": 900102
    },
    {
        "categoryId": 6000303,
        "categoryName": "猫粮",
        "parentId": 6000194
    },
    {
        "categoryId": 6000304,
        "categoryName": "狗粮",
        "parentId": 6000194
    },
    {
        "categoryId": 6000306,
        "categoryName": "冲牙器",
        "parentId": 900100
    },
    {
        "categoryId": 6000307,
        "categoryName": "按摩椅",
        "parentId": 900102
    },
    {
        "categoryId": 6000308,
        "categoryName": "按摩器",
        "parentId": 900102
    },
    {
        "categoryId": 6000309,
        "categoryName": "健身器材",
        "parentId": 801903
    },
    {
        "categoryId": 6000310,
        "categoryName": "护目镜",
        "parentId": 39
    },
    {
        "categoryId": 6000313,
        "categoryName": "冲锋裤",
        "parentId": 1902
    },
    {
        "categoryId": 6000314,
        "categoryName": "抓绒裤",
        "parentId": 1902
    },
    {
        "categoryId": 6000315,
        "categoryName": "软壳裤",
        "parentId": 1902
    },
    {
        "categoryId": 6000316,
        "categoryName": "速干裤",
        "parentId": 1902
    },
    {
        "categoryId": 6000317,
        "categoryName": "休闲裤",
        "parentId": 1902
    },
    {
        "categoryId": 6000318,
        "categoryName": "粤菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000319,
        "categoryName": "本帮菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000320,
        "categoryName": "淮扬菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000321,
        "categoryName": "鲁菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000322,
        "categoryName": "湘菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000323,
        "categoryName": "浙菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000324,
        "categoryName": "中西融合菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000325,
        "categoryName": "苏菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000326,
        "categoryName": "闽菜",
        "parentId": 6000251
    },
    {
        "categoryId": 6000327,
        "categoryName": "自加热食品",
        "parentId": 6000251
    },
    {
        "categoryId": 6000330,
        "categoryName": "颈部",
        "parentId": 7002
    },
    {
        "categoryId": 6000331,
        "categoryName": "脱毛",
        "parentId": 7002
    },
    {
        "categoryId": 6000332,
        "categoryName": "身体护理/脱毛膏",
        "parentId": 6000103
    },
    {
        "categoryId": 6000333,
        "categoryName": "调味酱",
        "parentId": 6000251
    },
    {
        "categoryId": 6000334,
        "categoryName": "粽子",
        "parentId": 6000022
    },
    {
        "categoryId": 6000335,
        "categoryName": "面部护理/爽肤水",
        "parentId": 6000103
    },
    {
        "categoryId": 6000337,
        "categoryName": "床笠",
        "parentId": 7101
    },
    {
        "categoryId": 6000338,
        "categoryName": "夏凉被",
        "parentId": 7102
    },
    {
        "categoryId": 6000339,
        "categoryName": "阿胶制品",
        "parentId": 6000022
    },
    {
        "categoryId": 6000340,
        "categoryName": "面部护理/洁面",
        "parentId": 6000103
    },
    {
        "categoryId": 6000341,
        "categoryName": "身体护理/颈部护理",
        "parentId": 6000103
    },
    {
        "categoryId": 6000342,
        "categoryName": "面部护理/乳液",
        "parentId": 6000103
    },
    {
        "categoryId": 6000343,
        "categoryName": "彩妆眼妆",
        "parentId": 6000103
    },
    {
        "categoryId": 6000344,
        "categoryName": "奶制品",
        "parentId": 6000022
    },
    {
        "categoryId": 6000345,
        "categoryName": "面部护理/卸妆水",
        "parentId": 6000103
    },
    {
        "categoryId": 6000346,
        "categoryName": "肉松/鱼松",
        "parentId": 6000022
    },
    {
        "categoryId": 6000347,
        "categoryName": "口腔护理",
        "parentId": 6000103
    },
    {
        "categoryId": 6000348,
        "categoryName": "身体护理/手足",
        "parentId": 6000103
    },
    {
        "categoryId": 6000349,
        "categoryName": "身体护理/洗发护发",
        "parentId": 6000103
    },
    {
        "categoryId": 6000350,
        "categoryName": "香水彩妆/香水",
        "parentId": 6000103
    },
    {
        "categoryId": 6000351,
        "categoryName": "手机平板手写笔",
        "parentId": 900000
    },
    {
        "categoryId": 6000352,
        "categoryName": "手机包",
        "parentId": 900000
    },
    {
        "categoryId": 6000354,
        "categoryName": "同屏器",
        "parentId": 900001
    },
    {
        "categoryId": 6000355,
        "categoryName": "笔筒",
        "parentId": 6000055
    },
    {
        "categoryId": 6000356,
        "categoryName": "灭蚊灯/灭蚊器",
        "parentId": 900101
    },
    {
        "categoryId": 6000357,
        "categoryName": "身体护理/沐浴护肤",
        "parentId": 6000103
    },
    {
        "categoryId": 6000358,
        "categoryName": "洗牙/冲牙器",
        "parentId": 900102
    },
    {
        "categoryId": 6000359,
        "categoryName": "蒸汽拖把",
        "parentId": 900101
    },
    {
        "categoryId": 6000361,
        "categoryName": "宝宝个护用品",
        "parentId": 4
    },
    {
        "categoryId": 6000362,
        "categoryName": "婴儿面部护理",
        "parentId": 6000361
    },
    {
        "categoryId": 6000363,
        "categoryName": "婴儿身体护理",
        "parentId": 6000361
    },
    {
        "categoryId": 6000364,
        "categoryName": "婴儿驱蚊",
        "parentId": 6000361
    },
    {
        "categoryId": 6000365,
        "categoryName": "定制",
        "parentId": 0
    },
    {
        "categoryId": 6000366,
        "categoryName": "服饰内衣",
        "parentId": 6000365
    },
    {
        "categoryId": 6000367,
        "categoryName": "家纺",
        "parentId": 6000365
    },
    {
        "categoryId": 6000368,
        "categoryName": "男士T恤",
        "parentId": 6000366
    },
    {
        "categoryId": 6000369,
        "categoryName": "男士POLO衫",
        "parentId": 6000366
    },
    {
        "categoryId": 6000370,
        "categoryName": "男士卫衣",
        "parentId": 6000366
    },
    {
        "categoryId": 6000371,
        "categoryName": "抱枕靠垫",
        "parentId": 6000367
    },
    {
        "categoryId": 6000372,
        "categoryName": "帆布袋",
        "parentId": 6000367
    },
    {
        "categoryId": 6000374,
        "categoryName": "手表",
        "parentId": 6000365
    },
    {
        "categoryId": 6000375,
        "categoryName": "石英表",
        "parentId": 6000374
    },
    {
        "categoryId": 6000376,
        "categoryName": "男士牛仔裤",
        "parentId": 6000366
    },
    {
        "categoryId": 6000377,
        "categoryName": "毛巾",
        "parentId": 6000367
    },
    {
        "categoryId": 6000380,
        "categoryName": "厨具",
        "parentId": 6000365
    },
    {
        "categoryId": 6000381,
        "categoryName": "保温杯",
        "parentId": 6000380
    },
    {
        "categoryId": 6000382,
        "categoryName": "保温壶",
        "parentId": 6000380
    },
    {
        "categoryId": 6000384,
        "categoryName": "鞋靴",
        "parentId": 6000365
    },
    {
        "categoryId": 6000385,
        "categoryName": "箱包",
        "parentId": 6000365
    },
    {
        "categoryId": 6000386,
        "categoryName": "男鞋",
        "parentId": 6000384
    },
    {
        "categoryId": 6000387,
        "categoryName": "女鞋",
        "parentId": 6000384
    },
    {
        "categoryId": 6000388,
        "categoryName": "拉杆箱",
        "parentId": 6000385
    },
    {
        "categoryId": 6000389,
        "categoryName": "双肩包",
        "parentId": 6000385
    },
    {
        "categoryId": 6000390,
        "categoryName": "3C数码",
        "parentId": 6000365
    },
    {
        "categoryId": 6000393,
        "categoryName": "女士T恤",
        "parentId": 6000366
    },
    {
        "categoryId": 6000394,
        "categoryName": "女士POLO衫",
        "parentId": 6000366
    },
    {
        "categoryId": 6000395,
        "categoryName": "女士卫衣",
        "parentId": 6000366
    },
    {
        "categoryId": 6000396,
        "categoryName": "女士牛仔裤",
        "parentId": 6000366
    },
    {
        "categoryId": 6000398,
        "categoryName": "鼠标垫",
        "parentId": 6000390
    },
    {
        "categoryId": 6000400,
        "categoryName": "手机保护套/壳",
        "parentId": 6000390
    },
    {
        "categoryId": 6000401,
        "categoryName": "移动电源",
        "parentId": 6000390
    },
    {
        "categoryId": 6000405,
        "categoryName": "收音机",
        "parentId": 6000390
    },
    {
        "categoryId": 6000406,
        "categoryName": "家用电器",
        "parentId": 6000365
    },
    {
        "categoryId": 6000407,
        "categoryName": "电动牙刷",
        "parentId": 6000406
    },
    {
        "categoryId": 6000410,
        "categoryName": "电吹风",
        "parentId": 6000406
    },
    {
        "categoryId": 6000411,
        "categoryName": "电水壶",
        "parentId": 6000406
    },
    {
        "categoryId": 6000412,
        "categoryName": "美妆个护",
        "parentId": 6000365
    },
    {
        "categoryId": 6000414,
        "categoryName": "面部护理",
        "parentId": 6000412
    },
    {
        "categoryId": 6000415,
        "categoryName": "身体护理",
        "parentId": 6000412
    },
    {
        "categoryId": 6000416,
        "categoryName": "洗发护发",
        "parentId": 6000412
    },
    {
        "categoryId": 6000417,
        "categoryName": "智能设备",
        "parentId": 9000
    },
    {
        "categoryId": 6000418,
        "categoryName": "智能手环",
        "parentId": 6000417
    },
    {
        "categoryId": 6000419,
        "categoryName": "月饼",
        "parentId": 6000022
    },
    {
        "categoryId": 6000422,
        "categoryName": "卤味制品",
        "parentId": 6000022
    },
    {
        "categoryId": 6000423,
        "categoryName": "宠物零食",
        "parentId": 6000194
    },
    {
        "categoryId": 6000426,
        "categoryName": "男士衬衫",
        "parentId": 6000366
    },
    {
        "categoryId": 6000427,
        "categoryName": "海味即食",
        "parentId": 6000022
    },
    {
        "categoryId": 6000429,
        "categoryName": "养生器械",
        "parentId": 6000029
    },
    {
        "categoryId": 6000432,
        "categoryName": "运动户外",
        "parentId": 6000365
    },
    {
        "categoryId": 6000433,
        "categoryName": "食品饮料",
        "parentId": 6000365
    },
    {
        "categoryId": 6000435,
        "categoryName": "运动T恤/背心",
        "parentId": 6000432
    },
    {
        "categoryId": 6000437,
        "categoryName": "夹克/外套",
        "parentId": 6000432
    },
    {
        "categoryId": 6000442,
        "categoryName": "运动袜",
        "parentId": 6000432
    },
    {
        "categoryId": 6000443,
        "categoryName": "马桶盖",
        "parentId": 62
    },
    {
        "categoryId": 6000445,
        "categoryName": "男士工装鞋",
        "parentId": 15
    },
    {
        "categoryId": 6000446,
        "categoryName": "男士腰带",
        "parentId": 6000366
    },
    {
        "categoryId": 6000450,
        "categoryName": "四件套",
        "parentId": 6000367
    },
    {
        "categoryId": 6000453,
        "categoryName": "猫/狗保健品",
        "parentId": 6000194
    },
    {
        "categoryId": 6000454,
        "categoryName": "饼干糕点",
        "parentId": 6000433
    },
    {
        "categoryId": 6000455,
        "categoryName": "茗茶",
        "parentId": 6000433
    },
    {
        "categoryId": 6000456,
        "categoryName": "饮料冲调",
        "parentId": 6000433
    },
    {
        "categoryId": 6000457,
        "categoryName": "手冲杯咖啡",
        "parentId": 6000128
    },
    {
        "categoryId": 6000458,
        "categoryName": "童装上装",
        "parentId": 6000366
    },
    {
        "categoryId": 6000468,
        "categoryName": "保护屏/防尘罩",
        "parentId": 6000052
    },
    {
        "categoryId": 6000469,
        "categoryName": "连接线/连接器/转换器",
        "parentId": 6000052
    },
    {
        "categoryId": 6000480,
        "categoryName": "装饰字画",
        "parentId": 6000367
    },
    {
        "categoryId": 6000483,
        "categoryName": "农特干调",
        "parentId": 6000004
    },
    {
        "categoryId": 6000484,
        "categoryName": "杂粮",
        "parentId": 6000483
    },
    {
        "categoryId": 6000485,
        "categoryName": "南北干货",
        "parentId": 6000483
    },
    {
        "categoryId": 6000486,
        "categoryName": "食用油",
        "parentId": 6000483
    },
    {
        "categoryId": 6000488,
        "categoryName": "海产干货",
        "parentId": 6000483
    },
    {
        "categoryId": 6000489,
        "categoryName": "传统滋补",
        "parentId": 6000483
    },
    {
        "categoryId": 6000490,
        "categoryName": "脱毛仪",
        "parentId": 900102
    },
    {
        "categoryId": 6000491,
        "categoryName": "理发器",
        "parentId": 900102
    },
    {
        "categoryId": 6000494,
        "categoryName": "女士卡包/钱包",
        "parentId": 6000385
    },
    {
        "categoryId": 6000496,
        "categoryName": "女士单肩包",
        "parentId": 6000385
    },
    {
        "categoryId": 6000497,
        "categoryName": "女士斜挎包",
        "parentId": 6000385
    },
    {
        "categoryId": 6000498,
        "categoryName": "鼠标垫/键盘垫",
        "parentId": 6000390
    },
    {
        "categoryId": 6000499,
        "categoryName": "香水彩妆",
        "parentId": 6000412
    },
    {
        "categoryId": 6000500,
        "categoryName": "男士单肩/斜挎包",
        "parentId": 6000385
    },
    {
        "categoryId": 6000502,
        "categoryName": "男士手拿包",
        "parentId": 6000385
    },
    {
        "categoryId": 6000503,
        "categoryName": "男士商务公文包",
        "parentId": 6000385
    },
    {
        "categoryId": 6000504,
        "categoryName": "海鲜礼盒",
        "parentId": 6000007
    },
    {
        "categoryId": 6000505,
        "categoryName": "平板电脑保护壳/套",
        "parentId": 6000390
    },
    {
        "categoryId": 6000506,
        "categoryName": "平板电脑保护壳/套",
        "parentId": 900000
    },
    {
        "categoryId": 6000508,
        "categoryName": "笔筒",
        "parentId": 6000390
    },
    {
        "categoryId": 6000512,
        "categoryName": "母婴",
        "parentId": 6000365
    },
    {
        "categoryId": 6000515,
        "categoryName": "围巾/丝巾",
        "parentId": 6000366
    },
    {
        "categoryId": 6000518,
        "categoryName": "发饰/发带",
        "parentId": 24
    },
    {
        "categoryId": 6000519,
        "categoryName": "眼罩",
        "parentId": 6000032
    },
    {
        "categoryId": 6000522,
        "categoryName": "水杯",
        "parentId": 6000380
    },
    {
        "categoryId": 6000528,
        "categoryName": "果蔬清洗机",
        "parentId": 900100
    },
    {
        "categoryId": 6000530,
        "categoryName": "空气炸锅",
        "parentId": 900100
    },
    {
        "categoryId": 6000531,
        "categoryName": "多功能锅",
        "parentId": 900100
    },
    {
        "categoryId": 6000532,
        "categoryName": "电热饭盒",
        "parentId": 900100
    },
    {
        "categoryId": 6000533,
        "categoryName": "消毒电器",
        "parentId": 900100
    },
    {
        "categoryId": 6000534,
        "categoryName": "除螨仪",
        "parentId": 900101
    },
    {
        "categoryId": 6000535,
        "categoryName": "研磨机",
        "parentId": 900100
    },
    {
        "categoryId": 6000536,
        "categoryName": "益智玩具",
        "parentId": 800403
    },
    {
        "categoryId": 6000538,
        "categoryName": "花瓶花艺",
        "parentId": 800103
    },
    {
        "categoryId": 6000539,
        "categoryName": "打蛋器",
        "parentId": 900100
    },
    {
        "categoryId": 6000540,
        "categoryName": "智能灯",
        "parentId": 63
    },
    {
        "categoryId": 6000547,
        "categoryName": "电压力锅",
        "parentId": 900100
    },
    {
        "categoryId": 6000548,
        "categoryName": "料理品",
        "parentId": 6000483
    },
    {
        "categoryId": 6000549,
        "categoryName": "腌卤制品",
        "parentId": 6000483
    },
    {
        "categoryId": 6000550,
        "categoryName": "豆制品",
        "parentId": 6000483
    },
    {
        "categoryId": 6000551,
        "categoryName": "罐头食品",
        "parentId": 6000022
    },
    {
        "categoryId": 6000552,
        "categoryName": "饮水机",
        "parentId": 900101
    },
    {
        "categoryId": 6000553,
        "categoryName": "电火锅",
        "parentId": 900100
    },
    {
        "categoryId": 6000554,
        "categoryName": "枕套",
        "parentId": 7101
    },
    {
        "categoryId": 6000560,
        "categoryName": "软足类",
        "parentId": 6000007
    },
    {
        "categoryId": 6000563,
        "categoryName": "电煮锅/电炖锅",
        "parentId": 900100
    },
    {
        "categoryId": 6000564,
        "categoryName": "手机支架",
        "parentId": 6000390
    },
    {
        "categoryId": 6000565,
        "categoryName": "眼罩/面罩",
        "parentId": 24
    },
    {
        "categoryId": 6000566,
        "categoryName": "无框眼镜",
        "parentId": 39
    },
    {
        "categoryId": 6000570,
        "categoryName": "鸡蛋",
        "parentId": 6000024
    },
    {
        "categoryId": 6000571,
        "categoryName": "鸭蛋",
        "parentId": 6000024
    },
    {
        "categoryId": 6000572,
        "categoryName": "鹅蛋",
        "parentId": 6000024
    },
    {
        "categoryId": 6000573,
        "categoryName": "鹌鹑蛋",
        "parentId": 6000024
    },
    {
        "categoryId": 6000576,
        "categoryName": "冷敷贴",
        "parentId": 7001
    },
    {
        "categoryId": 6000579,
        "categoryName": "生鲜水果",
        "parentId": 6000365
    },
    {
        "categoryId": 6000580,
        "categoryName": "海鲜水产",
        "parentId": 6000579
    },
    {
        "categoryId": 6000581,
        "categoryName": "消毒机",
        "parentId": 900101
    },
    {
        "categoryId": 6000582,
        "categoryName": "医疗保健",
        "parentId": 6000365
    },
    {
        "categoryId": 6000583,
        "categoryName": "口罩",
        "parentId": 6000582
    },
    {
        "categoryId": 6000584,
        "categoryName": "鸽子蛋",
        "parentId": 6000024
    },
    {
        "categoryId": 6000585,
        "categoryName": "鸽子",
        "parentId": 6000008
    },
    {
        "categoryId": 6000586,
        "categoryName": "藻类",
        "parentId": 6000007
    },
    {
        "categoryId": 6000587,
        "categoryName": "牙刷",
        "parentId": 807000
    },
    {
        "categoryId": 6000588,
        "categoryName": "乳品",
        "parentId": 6000004
    },
    {
        "categoryId": 6000589,
        "categoryName": "低温乳品",
        "parentId": 6000588
    },
    {
        "categoryId": 6000590,
        "categoryName": "常温乳品",
        "parentId": 6000588
    },
    {
        "categoryId": 6000591,
        "categoryName": "眼镜框",
        "parentId": 39
    },
    {
        "categoryId": 6000593,
        "categoryName": "面条机",
        "parentId": 900100
    },
    {
        "categoryId": 6000594,
        "categoryName": "和面机",
        "parentId": 900100
    },
    {
        "categoryId": 6000599,
        "categoryName": "沙发巾/套",
        "parentId": 7104
    },
    {
        "categoryId": 6000602,
        "categoryName": "电烤炉",
        "parentId": 900100
    },
    {
        "categoryId": 6000604,
        "categoryName": "洗碗机",
        "parentId": 900100
    },
    {
        "categoryId": 6000605,
        "categoryName": "冷冻面点",
        "parentId": 6000483
    },
    {
        "categoryId": 6000609,
        "categoryName": "保险柜/箱",
        "parentId": 47
    },
    {
        "categoryId": 6000610,
        "categoryName": "电竞桌",
        "parentId": 47
    },
    {
        "categoryId": 6000611,
        "categoryName": "电竞椅",
        "parentId": 47
    },
    {
        "categoryId": 6000612,
        "categoryName": "镀膜",
        "parentId": 6000078
    },
    {
        "categoryId": 6000613,
        "categoryName": "添加剂",
        "parentId": 6000096
    },
    {
        "categoryId": 6000614,
        "categoryName": "防冻液",
        "parentId": 6000096
    },
    {
        "categoryId": 6000615,
        "categoryName": "滤清器",
        "parentId": 6000096
    },
    {
        "categoryId": 6000616,
        "categoryName": "变速箱油/滤",
        "parentId": 6000096
    },
    {
        "categoryId": 6000618,
        "categoryName": "底盘装甲",
        "parentId": 6000096
    },
    {
        "categoryId": 6000619,
        "categoryName": "毛浴巾",
        "parentId": 71
    },
    {
        "categoryId": 6000620,
        "categoryName": "毛巾",
        "parentId": 6000619
    },
    {
        "categoryId": 6000621,
        "categoryName": "浴巾",
        "parentId": 6000619
    },
    {
        "categoryId": 6000622,
        "categoryName": "方巾",
        "parentId": 6000619
    },
    {
        "categoryId": 6000623,
        "categoryName": "地巾",
        "parentId": 6000619
    },
    {
        "categoryId": 6000624,
        "categoryName": "干发巾/帽",
        "parentId": 6000619
    },
    {
        "categoryId": 6000625,
        "categoryName": "升降桌",
        "parentId": 47
    },
    {
        "categoryId": 6000626,
        "categoryName": "酒类",
        "parentId": 6000019
    },
    {
        "categoryId": 6000627,
        "categoryName": "酱香白酒",
        "parentId": 6000626
    },
    {
        "categoryId": 6000628,
        "categoryName": "酱香白酒",
        "parentId": 6000433
    },
    {
        "categoryId": 6000629,
        "categoryName": "排球",
        "parentId": 801903
    },
    {
        "categoryId": 6000630,
        "categoryName": "礼品",
        "parentId": 0
    },
    {
        "categoryId": 6000631,
        "categoryName": "工艺礼品",
        "parentId": 6000630
    },
    {
        "categoryId": 6000632,
        "categoryName": "文创礼品",
        "parentId": 6000631
    },
    {
        "categoryId": 6000635,
        "categoryName": "狗玩具",
        "parentId": 6000195
    },
    {
        "categoryId": 6000636,
        "categoryName": "猫玩具",
        "parentId": 6000195
    },
    {
        "categoryId": 6000637,
        "categoryName": "猫爬架",
        "parentId": 6000195
    },
    {
        "categoryId": 6000638,
        "categoryName": "猫抓板",
        "parentId": 6000195
    },
    {
        "categoryId": 6000639,
        "categoryName": "集成水槽",
        "parentId": 900100
    },
    {
        "categoryId": 6000641,
        "categoryName": "骑行装备",
        "parentId": 801903
    },
    {
        "categoryId": 6000642,
        "categoryName": "石墨烯取暖",
        "parentId": 6000032
    },
    {
        "categoryId": 6000646,
        "categoryName": "家居日用",
        "parentId": 0
    },
    {
        "categoryId": 6000647,
        "categoryName": "家装软饰",
        "parentId": 6000646
    },
    {
        "categoryId": 6000648,
        "categoryName": "生活日用",
        "parentId": 6000646
    },
    {
        "categoryId": 6000649,
        "categoryName": "收纳用品",
        "parentId": 6000646
    },
    {
        "categoryId": 6000650,
        "categoryName": "园艺",
        "parentId": 6000646
    },
    {
        "categoryId": 6000651,
        "categoryName": "一次性用品",
        "parentId": 6000646
    },
    {
        "categoryId": 6000652,
        "categoryName": "装饰字画",
        "parentId": 6000647
    },
    {
        "categoryId": 6000653,
        "categoryName": "相框/照片墙",
        "parentId": 6000647
    },
    {
        "categoryId": 6000654,
        "categoryName": "装饰摆件",
        "parentId": 6000647
    },
    {
        "categoryId": 6000655,
        "categoryName": "花瓶",
        "parentId": 6000647
    },
    {
        "categoryId": 6000656,
        "categoryName": "仿真花",
        "parentId": 6000647
    },
    {
        "categoryId": 6000657,
        "categoryName": "仿真绿植",
        "parentId": 6000647
    },
    {
        "categoryId": 6000658,
        "categoryName": "创意家居",
        "parentId": 6000647
    },
    {
        "categoryId": 6000659,
        "categoryName": "香薰蜡烛",
        "parentId": 6000647
    },
    {
        "categoryId": 6000661,
        "categoryName": "雨伞雨具",
        "parentId": 6000648
    },
    {
        "categoryId": 6000662,
        "categoryName": "洗晒熨烫",
        "parentId": 6000648
    },
    {
        "categoryId": 6000663,
        "categoryName": "梳子",
        "parentId": 6000648
    },
    {
        "categoryId": 6000664,
        "categoryName": "热水袋",
        "parentId": 6000648
    },
    {
        "categoryId": 6000665,
        "categoryName": "防滑垫",
        "parentId": 6000648
    },
    {
        "categoryId": 6000667,
        "categoryName": "抽屉式收纳箱",
        "parentId": 6000649
    },
    {
        "categoryId": 6000668,
        "categoryName": "食物收纳箱",
        "parentId": 6000649
    },
    {
        "categoryId": 6000669,
        "categoryName": "置物架",
        "parentId": 6000649
    },
    {
        "categoryId": 6000670,
        "categoryName": "压缩袋",
        "parentId": 6000649
    },
    {
        "categoryId": 6000671,
        "categoryName": "收纳凳",
        "parentId": 6000649
    },
    {
        "categoryId": 6000672,
        "categoryName": "内衣收纳盒",
        "parentId": 6000649
    },
    {
        "categoryId": 6000673,
        "categoryName": "纸巾架",
        "parentId": 6000649
    },
    {
        "categoryId": 6000674,
        "categoryName": "整理箱/储物箱",
        "parentId": 6000649
    },
    {
        "categoryId": 6000675,
        "categoryName": "收纳桶",
        "parentId": 6000649
    },
    {
        "categoryId": 6000676,
        "categoryName": "鞋架",
        "parentId": 6000649
    },
    {
        "categoryId": 6000677,
        "categoryName": "衣帽架",
        "parentId": 6000649
    },
    {
        "categoryId": 6000678,
        "categoryName": "桌面收纳盒",
        "parentId": 6000649
    },
    {
        "categoryId": 6000679,
        "categoryName": "收纳挂袋",
        "parentId": 6000649
    },
    {
        "categoryId": 6000680,
        "categoryName": "脏衣篮/桶",
        "parentId": 6000649
    },
    {
        "categoryId": 6000681,
        "categoryName": "药盒/医药箱",
        "parentId": 6000649
    },
    {
        "categoryId": 6000682,
        "categoryName": "红酒架",
        "parentId": 6000649
    },
    {
        "categoryId": 6000683,
        "categoryName": "冰箱收纳盒",
        "parentId": 6000649
    },
    {
        "categoryId": 6000684,
        "categoryName": "首饰架/盒",
        "parentId": 6000649
    },
    {
        "categoryId": 6000685,
        "categoryName": "收纳罐/瓶",
        "parentId": 6000649
    },
    {
        "categoryId": 6000686,
        "categoryName": "洗衣袋",
        "parentId": 6000649
    },
    {
        "categoryId": 6000687,
        "categoryName": "洗漱手拿包",
        "parentId": 6000649
    },
    {
        "categoryId": 6000688,
        "categoryName": "线板收纳盒",
        "parentId": 6000649
    },
    {
        "categoryId": 6000689,
        "categoryName": "卫生巾收纳包",
        "parentId": 6000649
    },
    {
        "categoryId": 6000690,
        "categoryName": "数码收纳整理包",
        "parentId": 6000649
    },
    {
        "categoryId": 6000691,
        "categoryName": "园艺工具",
        "parentId": 6000650
    },
    {
        "categoryId": 6000692,
        "categoryName": "花盆花器",
        "parentId": 6000650
    },
    {
        "categoryId": 6000693,
        "categoryName": "灌溉设备",
        "parentId": 6000650
    },
    {
        "categoryId": 6000694,
        "categoryName": "保鲜膜/袋",
        "parentId": 6000651
    },
    {
        "categoryId": 6000695,
        "categoryName": "一次性餐饮用品",
        "parentId": 6000651
    },
    {
        "categoryId": 6000696,
        "categoryName": "鞋盒",
        "parentId": 6000649
    },
    {
        "categoryId": 6000697,
        "categoryName": "保健食品",
        "parentId": 6000019
    },
    {
        "categoryId": 6000698,
        "categoryName": "蛋白粉",
        "parentId": 6000697
    },
    {
        "categoryId": 6000699,
        "categoryName": "钙片",
        "parentId": 6000697
    },
    {
        "categoryId": 6000701,
        "categoryName": "保健食品",
        "parentId": 6000288
    },
    {
        "categoryId": 6000702,
        "categoryName": "口服液",
        "parentId": 6000697
    },
    {
        "categoryId": 6000703,
        "categoryName": "维生素类",
        "parentId": 6000697
    },
    {
        "categoryId": 6000704,
        "categoryName": "阿胶制品",
        "parentId": 6000697
    },
    {
        "categoryId": 6000705,
        "categoryName": "眼镜",
        "parentId": 6000365
    },
    {
        "categoryId": 6000706,
        "categoryName": "汽车用品",
        "parentId": 6000365
    },
    {
        "categoryId": 6000707,
        "categoryName": "礼品",
        "parentId": 6000365
    },
    {
        "categoryId": 6000708,
        "categoryName": "家装建材",
        "parentId": 6000365
    },
    {
        "categoryId": 6000709,
        "categoryName": "电脑办公",
        "parentId": 6000365
    },
    {
        "categoryId": 6000710,
        "categoryName": "运动户外",
        "parentId": 6000102
    },
    {
        "categoryId": 6000711,
        "categoryName": "方便食品",
        "parentId": 6000019
    },
    {
        "categoryId": 6000712,
        "categoryName": "医疗保健",
        "parentId": 6000102
    },
    {
        "categoryId": 6000713,
        "categoryName": "眼镜",
        "parentId": 6000102
    },
    {
        "categoryId": 6000714,
        "categoryName": "鞋靴",
        "parentId": 6000102
    },
    {
        "categoryId": 6000715,
        "categoryName": "箱包",
        "parentId": 6000102
    },
    {
        "categoryId": 6000716,
        "categoryName": "生鲜水果",
        "parentId": 6000102
    },
    {
        "categoryId": 6000717,
        "categoryName": "汽车用品",
        "parentId": 6000102
    },
    {
        "categoryId": 6000718,
        "categoryName": "礼品",
        "parentId": 6000102
    },
    {
        "categoryId": 6000719,
        "categoryName": "乒乓球",
        "parentId": 801903
    },
    {
        "categoryId": 6000720,
        "categoryName": "家居日用",
        "parentId": 6000365
    },
    {
        "categoryId": 6000721,
        "categoryName": "家装建材",
        "parentId": 6000102
    },
    {
        "categoryId": 6000722,
        "categoryName": "家用电器",
        "parentId": 6000102
    },
    {
        "categoryId": 6000723,
        "categoryName": "家居日用",
        "parentId": 6000102
    },
    {
        "categoryId": 6000724,
        "categoryName": "家纺",
        "parentId": 6000102
    },
    {
        "categoryId": 6000725,
        "categoryName": "服饰内衣",
        "parentId": 6000102
    },
    {
        "categoryId": 6000726,
        "categoryName": "电脑办公",
        "parentId": 6000102
    },
    {
        "categoryId": 6000727,
        "categoryName": "厨具",
        "parentId": 6000102
    },
    {
        "categoryId": 6000728,
        "categoryName": "3C数码",
        "parentId": 6000102
    },
    {
        "categoryId": 6000729,
        "categoryName": "手表",
        "parentId": 6000102
    },
    {
        "categoryId": 6000731,
        "categoryName": "平板电脑贴膜",
        "parentId": 900000
    },
    {
        "categoryId": 6000732,
        "categoryName": "平板电脑配件",
        "parentId": 900000
    },
    {
        "categoryId": 6000733,
        "categoryName": "手机贴膜",
        "parentId": 900000
    },
    {
        "categoryId": 6000734,
        "categoryName": "无线充电器",
        "parentId": 900000
    },
    {
        "categoryId": 6000735,
        "categoryName": "外接键盘",
        "parentId": 900000
    },
    {
        "categoryId": 6000736,
        "categoryName": "手机存储卡",
        "parentId": 900000
    },
    {
        "categoryId": 6000737,
        "categoryName": "笔记本电脑支架",
        "parentId": 6000164
    },
    {
        "categoryId": 6000738,
        "categoryName": "数码清洁用品",
        "parentId": 6000164
    },
    {
        "categoryId": 6000739,
        "categoryName": "苹果转换线",
        "parentId": 6000164
    },
    {
        "categoryId": 6000740,
        "categoryName": "转换接头",
        "parentId": 6000164
    },
    {
        "categoryId": 6000741,
        "categoryName": "USD转换器",
        "parentId": 6000164
    },
    {
        "categoryId": 6000742,
        "categoryName": "存储卡",
        "parentId": 6000164
    },
    {
        "categoryId": 6000743,
        "categoryName": "收音机",
        "parentId": 900001
    },
    {
        "categoryId": 6000744,
        "categoryName": "智能手表",
        "parentId": 6000417
    },
    {
        "categoryId": 6000745,
        "categoryName": "监控摄像头",
        "parentId": 6000417
    },
    {
        "categoryId": 6000746,
        "categoryName": "牵引绳/胸背带",
        "parentId": 6000199
    },
    {
        "categoryId": 6000747,
        "categoryName": "洗护美容",
        "parentId": 6000192
    },
    {
        "categoryId": 6000748,
        "categoryName": "浴液",
        "parentId": 6000747
    },
    {
        "categoryId": 6000749,
        "categoryName": "美容用具",
        "parentId": 6000747
    },
    {
        "categoryId": 6000750,
        "categoryName": "剪刀",
        "parentId": 805200
    },
    {
        "categoryId": 6000751,
        "categoryName": "水果削皮器",
        "parentId": 805200
    },
    {
        "categoryId": 6000753,
        "categoryName": "刀架",
        "parentId": 805200
    },
    {
        "categoryId": 6000754,
        "categoryName": "酒类",
        "parentId": 6000365
    },
    {
        "categoryId": 6000755,
        "categoryName": "保健食品",
        "parentId": 6000365
    },
    {
        "categoryId": 6000756,
        "categoryName": "酱香白酒",
        "parentId": 6000754
    },
    {
        "categoryId": 6000757,
        "categoryName": "浓香白酒",
        "parentId": 6000754
    },
    {
        "categoryId": 6000758,
        "categoryName": "清香白酒",
        "parentId": 6000754
    },
    {
        "categoryId": 6000759,
        "categoryName": "兼香白酒",
        "parentId": 6000754
    },
    {
        "categoryId": 6000761,
        "categoryName": "黄酒",
        "parentId": 6000754
    },
    {
        "categoryId": 6000762,
        "categoryName": "洋酒",
        "parentId": 6000754
    },
    {
        "categoryId": 6000763,
        "categoryName": "葡萄酒",
        "parentId": 6000754
    },
    {
        "categoryId": 6000764,
        "categoryName": "啤酒",
        "parentId": 6000754
    },
    {
        "categoryId": 6000765,
        "categoryName": "果酒",
        "parentId": 6000754
    },
    {
        "categoryId": 6000766,
        "categoryName": "蛋白粉",
        "parentId": 6000755
    },
    {
        "categoryId": 6000767,
        "categoryName": "钙片",
        "parentId": 6000755
    },
    {
        "categoryId": 6000768,
        "categoryName": "口服液",
        "parentId": 6000755
    },
    {
        "categoryId": 6000769,
        "categoryName": "维生素类",
        "parentId": 6000755
    },
    {
        "categoryId": 6000770,
        "categoryName": "阿胶制品",
        "parentId": 6000755
    },
    {
        "categoryId": 6000771,
        "categoryName": "酒类",
        "parentId": 6000102
    },
    {
        "categoryId": 6000772,
        "categoryName": "酱香白酒",
        "parentId": 6000771
    },
    {
        "categoryId": 6000773,
        "categoryName": "浓香白酒",
        "parentId": 6000771
    },
    {
        "categoryId": 6000774,
        "categoryName": "清香白酒",
        "parentId": 6000771
    },
    {
        "categoryId": 6000775,
        "categoryName": "兼香白酒",
        "parentId": 6000771
    },
    {
        "categoryId": 6000777,
        "categoryName": "黄酒",
        "parentId": 6000771
    },
    {
        "categoryId": 6000778,
        "categoryName": "洋酒",
        "parentId": 6000771
    },
    {
        "categoryId": 6000779,
        "categoryName": "葡萄酒",
        "parentId": 6000771
    },
    {
        "categoryId": 6000780,
        "categoryName": "啤酒",
        "parentId": 6000771
    },
    {
        "categoryId": 6000781,
        "categoryName": "果酒",
        "parentId": 6000771
    },
    {
        "categoryId": 6000782,
        "categoryName": "烹饪工具",
        "parentId": 52
    },
    {
        "categoryId": 6000783,
        "categoryName": "全套勺铲",
        "parentId": 6000782
    },
    {
        "categoryId": 6000784,
        "categoryName": "烹饪工具套装",
        "parentId": 6000782
    },
    {
        "categoryId": 6000785,
        "categoryName": "锅铲",
        "parentId": 6000782
    },
    {
        "categoryId": 6000786,
        "categoryName": "漏勺",
        "parentId": 6000782
    },
    {
        "categoryId": 6000787,
        "categoryName": "汤勺",
        "parentId": 6000782
    },
    {
        "categoryId": 6000788,
        "categoryName": "调味瓶罐",
        "parentId": 6000782
    },
    {
        "categoryId": 6000789,
        "categoryName": "油壶",
        "parentId": 6000782
    },
    {
        "categoryId": 6000790,
        "categoryName": "厨房储物/置物",
        "parentId": 52
    },
    {
        "categoryId": 6000791,
        "categoryName": "置物架/角架",
        "parentId": 6000790
    },
    {
        "categoryId": 6000792,
        "categoryName": "墙壁置物/挂架",
        "parentId": 6000790
    },
    {
        "categoryId": 6000793,
        "categoryName": "餐具笼/架",
        "parentId": 6000790
    },
    {
        "categoryId": 6000794,
        "categoryName": "锅盖架",
        "parentId": 6000790
    },
    {
        "categoryId": 6000795,
        "categoryName": "密封罐/储物罐",
        "parentId": 6000790
    },
    {
        "categoryId": 6000796,
        "categoryName": "米桶/米箱",
        "parentId": 6000790
    },
    {
        "categoryId": 6000797,
        "categoryName": "保鲜盒",
        "parentId": 6000790
    },
    {
        "categoryId": 6000800,
        "categoryName": "泡酒/菜桶",
        "parentId": 6000790
    },
    {
        "categoryId": 6000801,
        "categoryName": "厨用小工具",
        "parentId": 52
    },
    {
        "categoryId": 6000809,
        "categoryName": "其他厨房工具",
        "parentId": 6000801
    },
    {
        "categoryId": 6000810,
        "categoryName": "碟/盘",
        "parentId": 805201
    },
    {
        "categoryId": 6000811,
        "categoryName": "刀/叉/勺",
        "parentId": 805201
    },
    {
        "categoryId": 6000812,
        "categoryName": "饭盒/提锅",
        "parentId": 805201
    },
    {
        "categoryId": 6000813,
        "categoryName": "调羹/饭勺",
        "parentId": 805201
    },
    {
        "categoryId": 6000816,
        "categoryName": "餐垫/杯垫",
        "parentId": 805201
    },
    {
        "categoryId": 6000817,
        "categoryName": "便携/折叠餐具",
        "parentId": 805201
    },
    {
        "categoryId": 6000818,
        "categoryName": "水果叉/水果签",
        "parentId": 805201
    },
    {
        "categoryId": 6000819,
        "categoryName": "塑料杯",
        "parentId": 49
    },
    {
        "categoryId": 6000821,
        "categoryName": "焖烧杯",
        "parentId": 49
    },
    {
        "categoryId": 6000822,
        "categoryName": "USB风扇",
        "parentId": 6000164
    },
    {
        "categoryId": 6000823,
        "categoryName": "同屏线",
        "parentId": 6000164
    },
    {
        "categoryId": 6000824,
        "categoryName": "茶具",
        "parentId": 52
    },
    {
        "categoryId": 6000825,
        "categoryName": "保健食品",
        "parentId": 6000102
    },
    {
        "categoryId": 6000826,
        "categoryName": "茶具套装",
        "parentId": 6000824
    },
    {
        "categoryId": 6000827,
        "categoryName": "功夫茶具",
        "parentId": 6000824
    },
    {
        "categoryId": 6000828,
        "categoryName": "旅行茶具",
        "parentId": 6000824
    },
    {
        "categoryId": 6000829,
        "categoryName": "茶壶",
        "parentId": 6000824
    },
    {
        "categoryId": 6000830,
        "categoryName": "茶杯",
        "parentId": 6000824
    },
    {
        "categoryId": 6000831,
        "categoryName": "茶盘/茶台",
        "parentId": 6000824
    },
    {
        "categoryId": 6000832,
        "categoryName": "茶叶罐及茶具配件",
        "parentId": 6000824
    },
    {
        "categoryId": 6000834,
        "categoryName": "茶海/公道杯",
        "parentId": 6000824
    },
    {
        "categoryId": 6000836,
        "categoryName": "茶宠/摆件",
        "parentId": 6000824
    },
    {
        "categoryId": 6000837,
        "categoryName": "茶滤",
        "parentId": 6000824
    },
    {
        "categoryId": 6000838,
        "categoryName": "花草茶具",
        "parentId": 6000824
    },
    {
        "categoryId": 6000839,
        "categoryName": "咖啡器具",
        "parentId": 52
    },
    {
        "categoryId": 6000840,
        "categoryName": "咖啡杯",
        "parentId": 6000839
    },
    {
        "categoryId": 6000841,
        "categoryName": "咖啡壶",
        "parentId": 6000839
    },
    {
        "categoryId": 6000842,
        "categoryName": "咖啡套具",
        "parentId": 6000839
    },
    {
        "categoryId": 6000843,
        "categoryName": "磨豆机",
        "parentId": 6000839
    },
    {
        "categoryId": 6000844,
        "categoryName": "奶罐/糖罐",
        "parentId": 6000839
    },
    {
        "categoryId": 6000845,
        "categoryName": "酒具",
        "parentId": 52
    },
    {
        "categoryId": 6000846,
        "categoryName": "酒杯",
        "parentId": 6000845
    },
    {
        "categoryId": 6000848,
        "categoryName": "酒具套件",
        "parentId": 6000845
    },
    {
        "categoryId": 6000849,
        "categoryName": "醒酒器/调酒器/其它酒具",
        "parentId": 6000845
    },
    {
        "categoryId": 6000851,
        "categoryName": "烧烤用具",
        "parentId": 52
    },
    {
        "categoryId": 6000852,
        "categoryName": "烧烤炉",
        "parentId": 6000851
    },
    {
        "categoryId": 6000853,
        "categoryName": "烧烤盘",
        "parentId": 6000851
    },
    {
        "categoryId": 6000854,
        "categoryName": "烧烤刷",
        "parentId": 6000851
    },
    {
        "categoryId": 6000855,
        "categoryName": "烧烤夹/叉/铲/针",
        "parentId": 6000851
    },
    {
        "categoryId": 6000856,
        "categoryName": "烧烤用具套装",
        "parentId": 6000851
    },
    {
        "categoryId": 6000857,
        "categoryName": "键盘垫",
        "parentId": 6000052
    },
    {
        "categoryId": 6000858,
        "categoryName": "熏香",
        "parentId": 6000630
    },
    {
        "categoryId": 6000859,
        "categoryName": "香",
        "parentId": 6000858
    },
    {
        "categoryId": 6000860,
        "categoryName": "香器",
        "parentId": 6000858
    },
    {
        "categoryId": 6000861,
        "categoryName": "套装",
        "parentId": 6000858
    },
    {
        "categoryId": 6000862,
        "categoryName": "桌面收纳盒",
        "parentId": 6000720
    },
    {
        "categoryId": 6000863,
        "categoryName": "装饰字画",
        "parentId": 6000720
    },
    {
        "categoryId": 6000864,
        "categoryName": "雨伞雨具",
        "parentId": 6000720
    },
    {
        "categoryId": 6000865,
        "categoryName": "打底裤",
        "parentId": 21
    },
    {
        "categoryId": 6000866,
        "categoryName": "秋衣/秋裤",
        "parentId": 21
    },
    {
        "categoryId": 6000867,
        "categoryName": "挂钟",
        "parentId": 402
    },
    {
        "categoryId": 6000868,
        "categoryName": "外套",
        "parentId": 322
    },
    {
        "categoryId": 6000869,
        "categoryName": "套装",
        "parentId": 322
    },
    {
        "categoryId": 6000870,
        "categoryName": "背带裤",
        "parentId": 323
    },
    {
        "categoryId": 6000871,
        "categoryName": "香薰蜡烛",
        "parentId": 6000720
    },
    {
        "categoryId": 6000872,
        "categoryName": "梳子",
        "parentId": 6000720
    },
    {
        "categoryId": 6000873,
        "categoryName": "内衣收纳盒",
        "parentId": 6000720
    },
    {
        "categoryId": 6000874,
        "categoryName": "收纳挂袋",
        "parentId": 6000720
    },
    {
        "categoryId": 6000875,
        "categoryName": "职业装",
        "parentId": 323
    },
    {
        "categoryId": 6000876,
        "categoryName": "斗篷",
        "parentId": 323
    },
    {
        "categoryId": 6000877,
        "categoryName": "蕾丝裙",
        "parentId": 323
    },
    {
        "categoryId": 6000878,
        "categoryName": "铅笔裙",
        "parentId": 323
    },
    {
        "categoryId": 6000879,
        "categoryName": "不规则裙",
        "parentId": 323
    },
    {
        "categoryId": 6000880,
        "categoryName": "印花裙",
        "parentId": 323
    },
    {
        "categoryId": 6000881,
        "categoryName": "真丝裙",
        "parentId": 323
    },
    {
        "categoryId": 6000882,
        "categoryName": "百褶裙",
        "parentId": 323
    },
    {
        "categoryId": 6000883,
        "categoryName": "背心裙",
        "parentId": 323
    },
    {
        "categoryId": 6000884,
        "categoryName": "A字裙",
        "parentId": 323
    },
    {
        "categoryId": 6000885,
        "categoryName": "软管枕",
        "parentId": 7103
    },
    {
        "categoryId": 6000886,
        "categoryName": "花草枕",
        "parentId": 7103
    },
    {
        "categoryId": 6000887,
        "categoryName": "地垫",
        "parentId": 7104
    },
    {
        "categoryId": 6000888,
        "categoryName": "沙发垫",
        "parentId": 7104
    },
    {
        "categoryId": 6000889,
        "categoryName": "挂毯/壁毯",
        "parentId": 7104
    },
    {
        "categoryId": 6000890,
        "categoryName": "餐垫",
        "parentId": 7104
    },
    {
        "categoryId": 6000891,
        "categoryName": "毛巾套装",
        "parentId": 6000619
    },
    {
        "categoryId": 6000892,
        "categoryName": "角柜",
        "parentId": 46
    },
    {
        "categoryId": 6000893,
        "categoryName": "懒人沙发",
        "parentId": 46
    },
    {
        "categoryId": 6000894,
        "categoryName": "家用梯",
        "parentId": 6000159
    },
    {
        "categoryId": 6000895,
        "categoryName": "晾衣架",
        "parentId": 6000159
    },
    {
        "categoryId": 6000896,
        "categoryName": "智能晾衣架",
        "parentId": 6000159
    },
    {
        "categoryId": 6000897,
        "categoryName": "花架/装饰架",
        "parentId": 6000159
    },
    {
        "categoryId": 6000898,
        "categoryName": "儿童凳",
        "parentId": 53
    },
    {
        "categoryId": 6000899,
        "categoryName": "毛球修剪器",
        "parentId": 900101
    },
    {
        "categoryId": 6000900,
        "categoryName": "空调扇",
        "parentId": 900101
    },
    {
        "categoryId": 6000901,
        "categoryName": "煮茶器",
        "parentId": 900100
    },
    {
        "categoryId": 6000902,
        "categoryName": "餐边手推架",
        "parentId": 51
    },
    {
        "categoryId": 6000903,
        "categoryName": "足浴盆",
        "parentId": 900102
    },
    {
        "categoryId": 6000904,
        "categoryName": "足疗机",
        "parentId": 900102
    },
    {
        "categoryId": 6000905,
        "categoryName": "卷发棒",
        "parentId": 900102
    },
    {
        "categoryId": 6000906,
        "categoryName": "洁面仪",
        "parentId": 900102
    },
    {
        "categoryId": 6000907,
        "categoryName": "瘦脸仪",
        "parentId": 900102
    },
    {
        "categoryId": 6000908,
        "categoryName": "眼部按摩仪",
        "parentId": 900102
    },
    {
        "categoryId": 6000909,
        "categoryName": "鼻毛器",
        "parentId": 900102
    },
    {
        "categoryId": 6000910,
        "categoryName": "电视配件",
        "parentId": 6000111
    },
    {
        "categoryId": 6000911,
        "categoryName": "热水器",
        "parentId": 6000111
    },
    {
        "categoryId": 6000912,
        "categoryName": "烟机/灶具",
        "parentId": 6000111
    },
    {
        "categoryId": 6000913,
        "categoryName": "冰箱",
        "parentId": 6000111
    },
    {
        "categoryId": 6000914,
        "categoryName": "洗衣机/干衣机",
        "parentId": 6000111
    },
    {
        "categoryId": 6000915,
        "categoryName": "面盆",
        "parentId": 62
    },
    {
        "categoryId": 6000916,
        "categoryName": "浴帘",
        "parentId": 62
    },
    {
        "categoryId": 6000917,
        "categoryName": "智能马桶",
        "parentId": 62
    },
    {
        "categoryId": 6000918,
        "categoryName": "智能马桶盖",
        "parentId": 62
    },
    {
        "categoryId": 6000919,
        "categoryName": "净水软水",
        "parentId": 62
    },
    {
        "categoryId": 6000920,
        "categoryName": "厨卫配件",
        "parentId": 62
    },
    {
        "categoryId": 6000921,
        "categoryName": "电子锁",
        "parentId": 800102
    },
    {
        "categoryId": 6000922,
        "categoryName": "防晒",
        "parentId": 7001
    },
    {
        "categoryId": 6000923,
        "categoryName": "去角质",
        "parentId": 7001
    },
    {
        "categoryId": 6000924,
        "categoryName": "套装",
        "parentId": 7001
    },
    {
        "categoryId": 6000925,
        "categoryName": "BB霜",
        "parentId": 807003
    },
    {
        "categoryId": 6000926,
        "categoryName": "CC霜",
        "parentId": 807003
    },
    {
        "categoryId": 6000927,
        "categoryName": "隔离霜/妆前乳/打底",
        "parentId": 807003
    },
    {
        "categoryId": 6000928,
        "categoryName": "粉底液/膏",
        "parentId": 807003
    },
    {
        "categoryId": 6000929,
        "categoryName": "蜜粉/散粉",
        "parentId": 807003
    },
    {
        "categoryId": 6000930,
        "categoryName": "粉饼",
        "parentId": 807003
    },
    {
        "categoryId": 6000931,
        "categoryName": "唇彩/唇蜜/唇染",
        "parentId": 807003
    },
    {
        "categoryId": 6000932,
        "categoryName": "唇笔/唇线笔",
        "parentId": 807003
    },
    {
        "categoryId": 6000933,
        "categoryName": "眼影",
        "parentId": 807003
    },
    {
        "categoryId": 6000934,
        "categoryName": "眼线笔/眼线液/眼线膏",
        "parentId": 807003
    },
    {
        "categoryId": 6000935,
        "categoryName": "睫毛膏/睫毛增长液",
        "parentId": 807003
    },
    {
        "categoryId": 6000936,
        "categoryName": "彩妆套装",
        "parentId": 807003
    },
    {
        "categoryId": 6000937,
        "categoryName": "修颜/高光/阴影粉",
        "parentId": 807003
    },
    {
        "categoryId": 6000938,
        "categoryName": "遮瑕笔/遮瑕膏",
        "parentId": 807003
    },
    {
        "categoryId": 6000939,
        "categoryName": "指甲油",
        "parentId": 807003
    },
    {
        "categoryId": 6000940,
        "categoryName": "美妆工具",
        "parentId": 70
    },
    {
        "categoryId": 6000941,
        "categoryName": "化妆棉",
        "parentId": 6000940
    },
    {
        "categoryId": 6000942,
        "categoryName": "棉签/棉棒",
        "parentId": 6000940
    },
    {
        "categoryId": 6000943,
        "categoryName": "化妆刷",
        "parentId": 6000940
    },
    {
        "categoryId": 6000944,
        "categoryName": "粉扑/洗脸扑",
        "parentId": 6000940
    },
    {
        "categoryId": 6000945,
        "categoryName": "修眉刀",
        "parentId": 6000940
    },
    {
        "categoryId": 6000946,
        "categoryName": "化妆镜",
        "parentId": 6000940
    },
    {
        "categoryId": 6000947,
        "categoryName": "家庭清洁/纸品",
        "parentId": 0
    },
    {
        "categoryId": 6000948,
        "categoryName": "衣物清洁",
        "parentId": 6000947
    },
    {
        "categoryId": 6000949,
        "categoryName": "洗衣液/粉",
        "parentId": 6000948
    },
    {
        "categoryId": 6000950,
        "categoryName": "洗衣皂",
        "parentId": 6000948
    },
    {
        "categoryId": 6000951,
        "categoryName": "衣物护理剂",
        "parentId": 6000948
    },
    {
        "categoryId": 6000952,
        "categoryName": "衣物除菌片",
        "parentId": 6000948
    },
    {
        "categoryId": 6000953,
        "categoryName": "洗衣凝珠",
        "parentId": 6000948
    },
    {
        "categoryId": 6000954,
        "categoryName": "漂白/彩漂",
        "parentId": 6000948
    },
    {
        "categoryId": 6000955,
        "categoryName": "衣领净",
        "parentId": 6000948
    },
    {
        "categoryId": 6000956,
        "categoryName": "除菌液",
        "parentId": 6000948
    },
    {
        "categoryId": 6000957,
        "categoryName": "清洁用具",
        "parentId": 6000947
    },
    {
        "categoryId": 6000958,
        "categoryName": "拖把",
        "parentId": 6000957
    },
    {
        "categoryId": 6000959,
        "categoryName": "垃圾桶",
        "parentId": 6000957
    },
    {
        "categoryId": 6000960,
        "categoryName": "垃圾袋",
        "parentId": 6000957
    },
    {
        "categoryId": 6000961,
        "categoryName": "抹布/百洁布",
        "parentId": 6000957
    },
    {
        "categoryId": 6000962,
        "categoryName": "家务手套",
        "parentId": 6000957
    },
    {
        "categoryId": 6000963,
        "categoryName": "围裙/袖套",
        "parentId": 6000957
    },
    {
        "categoryId": 6000964,
        "categoryName": "清洁刷具",
        "parentId": 6000957
    },
    {
        "categoryId": 6000965,
        "categoryName": "扫把簸箕",
        "parentId": 6000957
    },
    {
        "categoryId": 6000966,
        "categoryName": "家用除尘掸",
        "parentId": 6000957
    },
    {
        "categoryId": 6000967,
        "categoryName": "其它清洁用具",
        "parentId": 6000957
    },
    {
        "categoryId": 6000968,
        "categoryName": "一次性清洁用具",
        "parentId": 6000957
    },
    {
        "categoryId": 6000969,
        "categoryName": "家庭环境清洁",
        "parentId": 6000947
    },
    {
        "categoryId": 6000970,
        "categoryName": "洗洁精",
        "parentId": 6000969
    },
    {
        "categoryId": 6000971,
        "categoryName": "油污清洁剂",
        "parentId": 6000969
    },
    {
        "categoryId": 6000972,
        "categoryName": "家电清洁用品",
        "parentId": 6000969
    },
    {
        "categoryId": 6000973,
        "categoryName": "洁厕剂",
        "parentId": 6000969
    },
    {
        "categoryId": 6000974,
        "categoryName": "消毒液",
        "parentId": 6000969
    },
    {
        "categoryId": 6000975,
        "categoryName": "管道疏通剂",
        "parentId": 6000969
    },
    {
        "categoryId": 6000976,
        "categoryName": "其它清洁用品",
        "parentId": 6000969
    },
    {
        "categoryId": 6000977,
        "categoryName": "其它",
        "parentId": 6000947
    },
    {
        "categoryId": 6000978,
        "categoryName": "室内除臭/芳香用品",
        "parentId": 6000977
    },
    {
        "categoryId": 6000979,
        "categoryName": "驱蚊用品",
        "parentId": 6000977
    },
    {
        "categoryId": 6000980,
        "categoryName": "除螨用品",
        "parentId": 6000977
    },
    {
        "categoryId": 6000981,
        "categoryName": "清洁纸品",
        "parentId": 6000947
    },
    {
        "categoryId": 6000982,
        "categoryName": "湿巾",
        "parentId": 6000981
    },
    {
        "categoryId": 6000983,
        "categoryName": "厨房纸巾",
        "parentId": 6000981
    },
    {
        "categoryId": 6000984,
        "categoryName": "湿厕纸",
        "parentId": 6000981
    },
    {
        "categoryId": 6000985,
        "categoryName": "清洁干巾",
        "parentId": 6000981
    },
    {
        "categoryId": 6000986,
        "categoryName": "抽纸",
        "parentId": 6000981
    },
    {
        "categoryId": 6000987,
        "categoryName": "手帕纸",
        "parentId": 6000981
    },
    {
        "categoryId": 6000988,
        "categoryName": "爽肤水/须后水",
        "parentId": 807005
    },
    {
        "categoryId": 6000989,
        "categoryName": "护肤套装",
        "parentId": 807005
    },
    {
        "categoryId": 6000990,
        "categoryName": "男士剃须膏",
        "parentId": 807005
    },
    {
        "categoryId": 6000991,
        "categoryName": "止汗露",
        "parentId": 7002
    },
    {
        "categoryId": 6000992,
        "categoryName": "身体磨砂",
        "parentId": 7002
    },
    {
        "categoryId": 6000993,
        "categoryName": "洗护套装",
        "parentId": 807002
    },
    {
        "categoryId": 6000994,
        "categoryName": "套装",
        "parentId": 807000
    },
    {
        "categoryId": 6000995,
        "categoryName": "裤型卫生巾",
        "parentId": 6000011
    },
    {
        "categoryId": 6000996,
        "categoryName": "其它女性护理产品",
        "parentId": 6000011
    },
    {
        "categoryId": 6000997,
        "categoryName": "美发假发/造型",
        "parentId": 70
    },
    {
        "categoryId": 6000998,
        "categoryName": "染发产品",
        "parentId": 6000997
    },
    {
        "categoryId": 6001000,
        "categoryName": "造型产品",
        "parentId": 6000997
    },
    {
        "categoryId": 6001001,
        "categoryName": "美发工具",
        "parentId": 6000997
    },
    {
        "categoryId": 6001002,
        "categoryName": "滑行车/扭扭车",
        "parentId": 26
    },
    {
        "categoryId": 6001003,
        "categoryName": "牙胶/固齿/咬咬袋",
        "parentId": 800405
    },
    {
        "categoryId": 6001004,
        "categoryName": "化妆包",
        "parentId": 831600
    },
    {
        "categoryId": 6001005,
        "categoryName": "车内除味剂",
        "parentId": 900200
    },
    {
        "categoryId": 6001006,
        "categoryName": "汽车防滑垫",
        "parentId": 900200
    },
    {
        "categoryId": 6001007,
        "categoryName": "仪表台防晒垫",
        "parentId": 900200
    },
    {
        "categoryId": 6001008,
        "categoryName": "车用收纳袋/盒",
        "parentId": 900200
    },
    {
        "categoryId": 6001009,
        "categoryName": "车载支架",
        "parentId": 900200
    },
    {
        "categoryId": 6001010,
        "categoryName": "洗车刷",
        "parentId": 6000078
    },
    {
        "categoryId": 6001011,
        "categoryName": "女士雨鞋/雨靴",
        "parentId": 10
    },
    {
        "categoryId": 6001012,
        "categoryName": "女士家居鞋",
        "parentId": 10
    },
    {
        "categoryId": 6001013,
        "categoryName": "商务休闲鞋",
        "parentId": 15
    },
    {
        "categoryId": 6001015,
        "categoryName": "男士家居鞋",
        "parentId": 15
    },
    {
        "categoryId": 6001016,
        "categoryName": "男士雨鞋/雨靴",
        "parentId": 15
    },
    {
        "categoryId": 6001017,
        "categoryName": "暖贴",
        "parentId": 6000032
    },
    {
        "categoryId": 6001018,
        "categoryName": "眼部保健",
        "parentId": 6000032
    },
    {
        "categoryId": 6001019,
        "categoryName": "护目镜/耳塞",
        "parentId": 6000032
    },
    {
        "categoryId": 6001020,
        "categoryName": "登山攀岩",
        "parentId": 801902
    },
    {
        "categoryId": 6001021,
        "categoryName": "垂钓用品",
        "parentId": 801902
    },
    {
        "categoryId": 6001022,
        "categoryName": "浓香白酒",
        "parentId": 6000626
    },
    {
        "categoryId": 6001023,
        "categoryName": "清香白酒",
        "parentId": 6000626
    },
    {
        "categoryId": 6001024,
        "categoryName": "兼香白酒",
        "parentId": 6000626
    },
    {
        "categoryId": 6001026,
        "categoryName": "黄酒",
        "parentId": 6000626
    },
    {
        "categoryId": 6001027,
        "categoryName": "洋酒",
        "parentId": 6000626
    },
    {
        "categoryId": 6001028,
        "categoryName": "葡萄酒",
        "parentId": 6000626
    },
    {
        "categoryId": 6001029,
        "categoryName": "啤酒",
        "parentId": 6000626
    },
    {
        "categoryId": 6001030,
        "categoryName": "果酒",
        "parentId": 6000626
    },
    {
        "categoryId": 6001031,
        "categoryName": "鸡肉丸/肉串",
        "parentId": 6000008
    },
    {
        "categoryId": 6001032,
        "categoryName": "鸭肉",
        "parentId": 6000008
    },
    {
        "categoryId": 6001033,
        "categoryName": "鹅肉",
        "parentId": 6000008
    },
    {
        "categoryId": 6001034,
        "categoryName": "牛肉丸/肉串",
        "parentId": 6000008
    },
    {
        "categoryId": 6001035,
        "categoryName": "米",
        "parentId": 6000483
    },
    {
        "categoryId": 6001036,
        "categoryName": "酱菜",
        "parentId": 6000020
    },
    {
        "categoryId": 6001037,
        "categoryName": "红糖/黑糖",
        "parentId": 6000020
    },
    {
        "categoryId": 6001038,
        "categoryName": "水果罐头",
        "parentId": 6000711
    },
    {
        "categoryId": 6001039,
        "categoryName": "肉罐头",
        "parentId": 6000711
    },
    {
        "categoryId": 6001040,
        "categoryName": "海鲜罐头",
        "parentId": 6000711
    },
    {
        "categoryId": 6001041,
        "categoryName": "节庆食品",
        "parentId": 6000019
    },
    {
        "categoryId": 6001042,
        "categoryName": "粽子",
        "parentId": 6001041
    },
    {
        "categoryId": 6001043,
        "categoryName": "月饼",
        "parentId": 6001041
    },
    {
        "categoryId": 6001044,
        "categoryName": "奶粉",
        "parentId": 6000128
    },
    {
        "categoryId": 6001045,
        "categoryName": "浓香白酒",
        "parentId": 6000433
    },
    {
        "categoryId": 6001046,
        "categoryName": "清香白酒",
        "parentId": 6000433
    },
    {
        "categoryId": 6001047,
        "categoryName": "兼香白酒",
        "parentId": 6000433
    },
    {
        "categoryId": 6001049,
        "categoryName": "黄酒",
        "parentId": 6000433
    },
    {
        "categoryId": 6001050,
        "categoryName": "洋酒",
        "parentId": 6000433
    },
    {
        "categoryId": 6001051,
        "categoryName": "葡萄酒",
        "parentId": 6000433
    },
    {
        "categoryId": 6001052,
        "categoryName": "啤酒",
        "parentId": 6000433
    },
    {
        "categoryId": 6001053,
        "categoryName": "果酒",
        "parentId": 6000433
    },
    {
        "categoryId": 6001054,
        "categoryName": "低温乳品",
        "parentId": 6000128
    },
    {
        "categoryId": 6001055,
        "categoryName": "常温乳品",
        "parentId": 6000128
    },
    {
        "categoryId": 6001056,
        "categoryName": "水",
        "parentId": 6000128
    },
    {
        "categoryId": 6001058,
        "categoryName": "婴幼T恤",
        "parentId": 800402
    },
    {
        "categoryId": 6001059,
        "categoryName": "婴幼衬衫",
        "parentId": 800402
    },
    {
        "categoryId": 6001060,
        "categoryName": "披风/斗篷",
        "parentId": 800402
    },
    {
        "categoryId": 6001061,
        "categoryName": "手巾/口水巾/三角巾",
        "parentId": 800402
    },
    {
        "categoryId": 6001062,
        "categoryName": "洗衣液/皂/柔顺剂",
        "parentId": 6000361
    },
    {
        "categoryId": 6001063,
        "categoryName": "儿童包",
        "parentId": 27
    },
    {
        "categoryId": 6001064,
        "categoryName": "皮裙",
        "parentId": 323
    },
    {
        "categoryId": 6001065,
        "categoryName": "皮裤",
        "parentId": 323
    },
    {
        "categoryId": 6001066,
        "categoryName": "其它婴童用品",
        "parentId": 4
    },
    {
        "categoryId": 6001067,
        "categoryName": "防撞/防触电",
        "parentId": 6001066
    },
    {
        "categoryId": 6001068,
        "categoryName": "香薰机",
        "parentId": 900101
    },
    {
        "categoryId": 6001069,
        "categoryName": "骑行服",
        "parentId": 801901
    },
    {
        "categoryId": 6001070,
        "categoryName": "足球服",
        "parentId": 801901
    },
    {
        "categoryId": 6001071,
        "categoryName": "篮球服",
        "parentId": 801901
    },
    {
        "categoryId": 6001072,
        "categoryName": "滑雪用品",
        "parentId": 801903
    },
    {
        "categoryId": 6001073,
        "categoryName": "中医保健",
        "parentId": 6000029
    },
    {
        "categoryId": 6001074,
        "categoryName": "隐形眼镜",
        "parentId": 7
    },
    {
        "categoryId": 6001075,
        "categoryName": "透明隐形眼镜",
        "parentId": 6001074
    },
    {
        "categoryId": 6001076,
        "categoryName": "彩色隐形眼镜",
        "parentId": 6001074
    },
    {
        "categoryId": 6001077,
        "categoryName": "隐形眼镜润滑液",
        "parentId": 6001074
    },
    {
        "categoryId": 6001078,
        "categoryName": "隐形眼镜护理液",
        "parentId": 6001074
    },
    {
        "categoryId": 6001079,
        "categoryName": "洗眼液",
        "parentId": 6001074
    },
    {
        "categoryId": 6001080,
        "categoryName": "护理工具",
        "parentId": 6001074
    },
    {
        "categoryId": 6001081,
        "categoryName": "破壁机",
        "parentId": 6000406
    },
    {
        "categoryId": 6001082,
        "categoryName": "挂烫机",
        "parentId": 6000406
    },
    {
        "categoryId": 6001083,
        "categoryName": "榨汁杯",
        "parentId": 6000406
    },
    {
        "categoryId": 6001084,
        "categoryName": "绞肉机",
        "parentId": 6000406
    },
    {
        "categoryId": 6001085,
        "categoryName": "电蒸笼",
        "parentId": 6000406
    },
    {
        "categoryId": 6001089,
        "categoryName": "洗菜机",
        "parentId": 6000406
    },
    {
        "categoryId": 6001090,
        "categoryName": "吸尘器",
        "parentId": 6000406
    },
    {
        "categoryId": 6001091,
        "categoryName": "电陶炉",
        "parentId": 6000406
    },
    {
        "categoryId": 6001092,
        "categoryName": "烹饪锅",
        "parentId": 6000406
    },
    {
        "categoryId": 6001093,
        "categoryName": "打蛋器",
        "parentId": 6000406
    },
    {
        "categoryId": 6001094,
        "categoryName": "电煮锅/电炖锅",
        "parentId": 6000406
    },
    {
        "categoryId": 6001095,
        "categoryName": "电火锅",
        "parentId": 6000406
    },
    {
        "categoryId": 6001096,
        "categoryName": "养生壶",
        "parentId": 6000406
    },
    {
        "categoryId": 6001097,
        "categoryName": "电蒸锅",
        "parentId": 6000406
    },
    {
        "categoryId": 6001098,
        "categoryName": "电饭煲",
        "parentId": 6000406
    },
    {
        "categoryId": 6001099,
        "categoryName": "蒸汽拖地机",
        "parentId": 6000406
    },
    {
        "categoryId": 6001100,
        "categoryName": "套装",
        "parentId": 6000707
    },
    {
        "categoryId": 6001101,
        "categoryName": "橄榄球",
        "parentId": 801903
    },
    {
        "categoryId": 6001102,
        "categoryName": "防染吸色片",
        "parentId": 6000948
    },
    {
        "categoryId": 6001104,
        "categoryName": "口腔喷雾",
        "parentId": 807000
    },
    {
        "categoryId": 6001105,
        "categoryName": "女鞋配件",
        "parentId": 10
    },
    {
        "categoryId": 6001106,
        "categoryName": "男鞋配件",
        "parentId": 15
    },
    {
        "categoryId": 6001108,
        "categoryName": "电热饭盒",
        "parentId": 6000406
    },
    {
        "categoryId": 6001109,
        "categoryName": "皮具护理液",
        "parentId": 6000977
    },
    {
        "categoryId": 6001110,
        "categoryName": "香氛喷雾",
        "parentId": 6000948
    },
    {
        "categoryId": 6001111,
        "categoryName": "一次性内裤",
        "parentId": 6000011
    },
    {
        "categoryId": 6001112,
        "categoryName": "南北干货",
        "parentId": 6000579
    },
    {
        "categoryId": 6001113,
        "categoryName": "传统滋补",
        "parentId": 6000579
    },
    {
        "categoryId": 6001114,
        "categoryName": "蜂蜜/柚子茶",
        "parentId": 6000433
    },
    {
        "categoryId": 6001115,
        "categoryName": "滋补品",
        "parentId": 6000433
    },
    {
        "categoryId": 6001116,
        "categoryName": "糖果/巧克力",
        "parentId": 6000433
    },
    {
        "categoryId": 6001117,
        "categoryName": "阿胶制品",
        "parentId": 6000433
    },
    {
        "categoryId": 6001118,
        "categoryName": "桌布罩件",
        "parentId": 6000367
    },
    {
        "categoryId": 6001119,
        "categoryName": "被套",
        "parentId": 6000367
    },
    {
        "categoryId": 6001120,
        "categoryName": "蚕丝被",
        "parentId": 6000367
    },
    {
        "categoryId": 6001121,
        "categoryName": "冲锋衣",
        "parentId": 6000432
    },
    {
        "categoryId": 6001122,
        "categoryName": "男士夹克",
        "parentId": 6000366
    },
    {
        "categoryId": 6001123,
        "categoryName": "男士休闲裤",
        "parentId": 6000366
    },
    {
        "categoryId": 6001124,
        "categoryName": "女士职业套装",
        "parentId": 6000366
    },
    {
        "categoryId": 6001125,
        "categoryName": "男士西服套装",
        "parentId": 6000366
    },
    {
        "categoryId": 6001126,
        "categoryName": "女装衬衫",
        "parentId": 6000366
    },
    {
        "categoryId": 6001127,
        "categoryName": "男士正装裤",
        "parentId": 6000366
    },
    {
        "categoryId": 6001128,
        "categoryName": "户外风衣",
        "parentId": 6000432
    },
    {
        "categoryId": 6001129,
        "categoryName": "速干裤",
        "parentId": 6000432
    },
    {
        "categoryId": 6001130,
        "categoryName": "毯子",
        "parentId": 6000367
    },
    {
        "categoryId": 6001131,
        "categoryName": "浴巾",
        "parentId": 6000367
    },
    {
        "categoryId": 6001132,
        "categoryName": "其他多件套",
        "parentId": 6000367
    },
    {
        "categoryId": 6001133,
        "categoryName": "羽绒被",
        "parentId": 6000367
    },
    {
        "categoryId": 6001134,
        "categoryName": "枕套",
        "parentId": 6000367
    },
    {
        "categoryId": 6001135,
        "categoryName": "浴衣/浴袍",
        "parentId": 6000367
    },
    {
        "categoryId": 6001136,
        "categoryName": "羊毛被/驼毛被",
        "parentId": 6000367
    },
    {
        "categoryId": 6001137,
        "categoryName": "羽绒枕",
        "parentId": 6000367
    },
    {
        "categoryId": 6001138,
        "categoryName": "乳胶枕",
        "parentId": 6000367
    },
    {
        "categoryId": 6001139,
        "categoryName": "记忆枕",
        "parentId": 6000367
    },
    {
        "categoryId": 6001140,
        "categoryName": "办公文具",
        "parentId": 6000055
    },
    {
        "categoryId": 6001141,
        "categoryName": "儿童自行车",
        "parentId": 6000512
    },
    {
        "categoryId": 6001143,
        "categoryName": "学步车",
        "parentId": 6000512
    },
    {
        "categoryId": 6001144,
        "categoryName": "滑行车/扭扭车",
        "parentId": 6000512
    },
    {
        "categoryId": 6001145,
        "categoryName": "滑板车",
        "parentId": 6000512
    },
    {
        "categoryId": 6001146,
        "categoryName": "电动车",
        "parentId": 6000512
    },
    {
        "categoryId": 6001147,
        "categoryName": "发套假发",
        "parentId": 6000997
    },
    {
        "categoryId": 6001148,
        "categoryName": "其它假发",
        "parentId": 6000997
    },
    {
        "categoryId": 6001149,
        "categoryName": "猫砂",
        "parentId": 6000193
    },
    {
        "categoryId": 6001150,
        "categoryName": "定制家具",
        "parentId": 8
    },
    {
        "categoryId": 6001151,
        "categoryName": "衣柜",
        "parentId": 6001150
    },
    {
        "categoryId": 6001152,
        "categoryName": "鞋柜",
        "parentId": 6001150
    },
    {
        "categoryId": 6001153,
        "categoryName": "书柜",
        "parentId": 6001150
    },
    {
        "categoryId": 6001154,
        "categoryName": "玄关柜",
        "parentId": 6001150
    },
    {
        "categoryId": 6001155,
        "categoryName": "筷子",
        "parentId": 6000380
    },
    {
        "categoryId": 6001156,
        "categoryName": "膳食纤维",
        "parentId": 6000697
    },
    {
        "categoryId": 6001157,
        "categoryName": "叶黄素",
        "parentId": 6000697
    },
    {
        "categoryId": 6001158,
        "categoryName": "褪黑素",
        "parentId": 6000697
    },
    {
        "categoryId": 6001159,
        "categoryName": "胶原蛋白",
        "parentId": 6000697
    },
    {
        "categoryId": 6001160,
        "categoryName": "酵素",
        "parentId": 6000697
    },
    {
        "categoryId": 6001161,
        "categoryName": "膳食纤维",
        "parentId": 6000755
    },
    {
        "categoryId": 6001162,
        "categoryName": "叶黄素",
        "parentId": 6000755
    },
    {
        "categoryId": 6001163,
        "categoryName": "褪黑素",
        "parentId": 6000755
    },
    {
        "categoryId": 6001164,
        "categoryName": "胶原蛋白",
        "parentId": 6000755
    },
    {
        "categoryId": 6001165,
        "categoryName": "酵素",
        "parentId": 6000755
    },
    {
        "categoryId": 6001166,
        "categoryName": "烟机灶具配件",
        "parentId": 6000111
    },
    {
        "categoryId": 6001167,
        "categoryName": "充电器",
        "parentId": 6000390
    },
    {
        "categoryId": 6001168,
        "categoryName": "眼镜组合",
        "parentId": 39
    },
    {
        "categoryId": 6001169,
        "categoryName": "电热杯",
        "parentId": 900100
    },
    {
        "categoryId": 6001170,
        "categoryName": "私密护理",
        "parentId": 6000011
    },
    {
        "categoryId": 6001171,
        "categoryName": "口腔护理杯",
        "parentId": 807000
    },
    {
        "categoryId": 6001172,
        "categoryName": "胶囊",
        "parentId": 6000697
    },
    {
        "categoryId": 6001173,
        "categoryName": "软糖",
        "parentId": 6000697
    },
    {
        "categoryId": 6001174,
        "categoryName": "胶囊",
        "parentId": 6000755
    },
    {
        "categoryId": 6001175,
        "categoryName": "软糖",
        "parentId": 6000755
    },
    {
        "categoryId": 6001176,
        "categoryName": "空气净化器耗材",
        "parentId": 900101
    },
    {
        "categoryId": 6001177,
        "categoryName": "运动拖鞋",
        "parentId": 14
    },
    {
        "categoryId": 6001178,
        "categoryName": "运动休闲鞋",
        "parentId": 14
    },
    {
        "categoryId": 6001179,
        "categoryName": "运动凉鞋",
        "parentId": 14
    },
    {
        "categoryId": 6001180,
        "categoryName": "童鞋运动鞋",
        "parentId": 13
    },
    {
        "categoryId": 6001181,
        "categoryName": "学步鞋",
        "parentId": 13
    },
    {
        "categoryId": 6001182,
        "categoryName": "童鞋雪地靴",
        "parentId": 13
    },
    {
        "categoryId": 6001183,
        "categoryName": "亲子鞋",
        "parentId": 13
    },
    {
        "categoryId": 6001184,
        "categoryName": "童鞋凉鞋",
        "parentId": 13
    },
    {
        "categoryId": 6001185,
        "categoryName": "童鞋帆布鞋",
        "parentId": 13
    },
    {
        "categoryId": 6001186,
        "categoryName": "童鞋拖鞋",
        "parentId": 13
    },
    {
        "categoryId": 6001187,
        "categoryName": "户外鞋",
        "parentId": 2
    },
    {
        "categoryId": 6001188,
        "categoryName": "徒步鞋",
        "parentId": 6001187
    },
    {
        "categoryId": 6001189,
        "categoryName": "登山鞋",
        "parentId": 6001187
    },
    {
        "categoryId": 6001190,
        "categoryName": "越野跑鞋",
        "parentId": 6001187
    },
    {
        "categoryId": 6001191,
        "categoryName": "户外沙滩鞋/凉鞋/拖鞋",
        "parentId": 6001187
    },
    {
        "categoryId": 6001192,
        "categoryName": "户外休闲鞋",
        "parentId": 6001187
    },
    {
        "categoryId": 6001193,
        "categoryName": "气泡水机/苏打水机",
        "parentId": 900101
    },
    {
        "categoryId": 6001194,
        "categoryName": "洗鼻器",
        "parentId": 900102
    },
    {
        "categoryId": 6001195,
        "categoryName": "防晒衣",
        "parentId": 1902
    },
    {
        "categoryId": 6001196,
        "categoryName": "防晒裤",
        "parentId": 1902
    },
    {
        "categoryId": 6001197,
        "categoryName": "户外套装",
        "parentId": 1902
    },
    {
        "categoryId": 6001198,
        "categoryName": "户外马甲",
        "parentId": 1902
    },
    {
        "categoryId": 6001199,
        "categoryName": "暴汗服",
        "parentId": 801901
    },
    {
        "categoryId": 6001200,
        "categoryName": "运动POLO",
        "parentId": 801901
    },
    {
        "categoryId": 6001201,
        "categoryName": "运动护具",
        "parentId": 801903
    },
    {
        "categoryId": 6001202,
        "categoryName": "珠宝首饰",
        "parentId": 0
    },
    {
        "categoryId": 6001203,
        "categoryName": "K金饰品",
        "parentId": 6001202
    },
    {
        "categoryId": 6001204,
        "categoryName": "K金吊坠",
        "parentId": 6001203
    },
    {
        "categoryId": 6001205,
        "categoryName": "K金耳饰",
        "parentId": 6001203
    },
    {
        "categoryId": 6001206,
        "categoryName": "K金戒指",
        "parentId": 6001203
    },
    {
        "categoryId": 6001207,
        "categoryName": "K金手镯/手链/脚链",
        "parentId": 6001203
    },
    {
        "categoryId": 6001208,
        "categoryName": "K金项链",
        "parentId": 6001203
    },
    {
        "categoryId": 6001209,
        "categoryName": "铂金",
        "parentId": 6001202
    },
    {
        "categoryId": 6001210,
        "categoryName": "铂金",
        "parentId": 6001209
    },
    {
        "categoryId": 6001211,
        "categoryName": "彩宝",
        "parentId": 6001202
    },
    {
        "categoryId": 6001212,
        "categoryName": "吊坠",
        "parentId": 6001211
    },
    {
        "categoryId": 6001213,
        "categoryName": "耳饰",
        "parentId": 6001211
    },
    {
        "categoryId": 6001214,
        "categoryName": "戒指",
        "parentId": 6001211
    },
    {
        "categoryId": 6001215,
        "categoryName": "手链",
        "parentId": 6001211
    },
    {
        "categoryId": 6001216,
        "categoryName": "项链",
        "parentId": 6001211
    },
    {
        "categoryId": 6001217,
        "categoryName": "发饰",
        "parentId": 6001202
    },
    {
        "categoryId": 6001218,
        "categoryName": "发饰",
        "parentId": 6001217
    },
    {
        "categoryId": 6001219,
        "categoryName": "翡翠",
        "parentId": 6001202
    },
    {
        "categoryId": 6001220,
        "categoryName": "翡翠吊坠",
        "parentId": 6001219
    },
    {
        "categoryId": 6001221,
        "categoryName": "翡翠耳饰",
        "parentId": 6001219
    },
    {
        "categoryId": 6001222,
        "categoryName": "翡翠戒指",
        "parentId": 6001219
    },
    {
        "categoryId": 6001223,
        "categoryName": "翡翠手镯",
        "parentId": 6001219
    },
    {
        "categoryId": 6001224,
        "categoryName": "挂件/摆件/把件",
        "parentId": 6001219
    },
    {
        "categoryId": 6001225,
        "categoryName": "合成/人工宝石",
        "parentId": 6001202
    },
    {
        "categoryId": 6001226,
        "categoryName": "合成/人工宝石",
        "parentId": 6001225
    },
    {
        "categoryId": 6001227,
        "categoryName": "和田玉",
        "parentId": 6001202
    },
    {
        "categoryId": 6001228,
        "categoryName": "和田玉吊坠",
        "parentId": 6001227
    },
    {
        "categoryId": 6001229,
        "categoryName": "和田玉耳饰",
        "parentId": 6001227
    },
    {
        "categoryId": 6001230,
        "categoryName": "和田玉戒指",
        "parentId": 6001227
    },
    {
        "categoryId": 6001231,
        "categoryName": "和田玉手链",
        "parentId": 6001227
    },
    {
        "categoryId": 6001232,
        "categoryName": "和田玉手镯",
        "parentId": 6001227
    },
    {
        "categoryId": 6001233,
        "categoryName": "和田玉项链",
        "parentId": 6001227
    },
    {
        "categoryId": 6001234,
        "categoryName": "黄金饰品",
        "parentId": 6001202
    },
    {
        "categoryId": 6001235,
        "categoryName": "黄金吊坠",
        "parentId": 6001234
    },
    {
        "categoryId": 6001236,
        "categoryName": "黄金耳饰",
        "parentId": 6001234
    },
    {
        "categoryId": 6001237,
        "categoryName": "黄金戒指",
        "parentId": 6001234
    },
    {
        "categoryId": 6001238,
        "categoryName": "黄金手链/脚链",
        "parentId": 6001234
    },
    {
        "categoryId": 6001239,
        "categoryName": "黄金手镯",
        "parentId": 6001234
    },
    {
        "categoryId": 6001240,
        "categoryName": "黄金项链",
        "parentId": 6001234
    },
    {
        "categoryId": 6001241,
        "categoryName": "黄金转运珠",
        "parentId": 6001234
    },
    {
        "categoryId": 6001251,
        "categoryName": "其它玉石",
        "parentId": 6001202
    },
    {
        "categoryId": 6001252,
        "categoryName": "其它玉石",
        "parentId": 6001251
    },
    {
        "categoryId": 6001253,
        "categoryName": "时尚饰品",
        "parentId": 6001202
    },
    {
        "categoryId": 6001254,
        "categoryName": "耳饰",
        "parentId": 6001253
    },
    {
        "categoryId": 6001255,
        "categoryName": "婚庆饰品",
        "parentId": 6001253
    },
    {
        "categoryId": 6001256,
        "categoryName": "戒指",
        "parentId": 6001253
    },
    {
        "categoryId": 6001257,
        "categoryName": "毛衣链",
        "parentId": 6001253
    },
    {
        "categoryId": 6001258,
        "categoryName": "饰品配件",
        "parentId": 6001253
    },
    {
        "categoryId": 6001259,
        "categoryName": "手链/脚链",
        "parentId": 6001253
    },
    {
        "categoryId": 6001260,
        "categoryName": "项链",
        "parentId": 6001253
    },
    {
        "categoryId": 6001261,
        "categoryName": "胸针",
        "parentId": 6001253
    },
    {
        "categoryId": 6001262,
        "categoryName": "水晶玛瑙",
        "parentId": 6001202
    },
    {
        "categoryId": 6001263,
        "categoryName": "水晶玛瑙",
        "parentId": 6001262
    },
    {
        "categoryId": 6001264,
        "categoryName": "银饰",
        "parentId": 6001202
    },
    {
        "categoryId": 6001265,
        "categoryName": "宝宝银饰",
        "parentId": 6001264
    },
    {
        "categoryId": 6001266,
        "categoryName": "银吊坠/项链",
        "parentId": 6001264
    },
    {
        "categoryId": 6001267,
        "categoryName": "银耳饰",
        "parentId": 6001264
    },
    {
        "categoryId": 6001268,
        "categoryName": "银戒指",
        "parentId": 6001264
    },
    {
        "categoryId": 6001269,
        "categoryName": "银手链/脚链",
        "parentId": 6001264
    },
    {
        "categoryId": 6001270,
        "categoryName": "银手镯",
        "parentId": 6001264
    },
    {
        "categoryId": 6001271,
        "categoryName": "珍珠",
        "parentId": 6001202
    },
    {
        "categoryId": 6001272,
        "categoryName": "珍珠吊坠",
        "parentId": 6001271
    },
    {
        "categoryId": 6001273,
        "categoryName": "珍珠耳饰",
        "parentId": 6001271
    },
    {
        "categoryId": 6001274,
        "categoryName": "珍珠戒指",
        "parentId": 6001271
    },
    {
        "categoryId": 6001275,
        "categoryName": "珍珠手链",
        "parentId": 6001271
    },
    {
        "categoryId": 6001276,
        "categoryName": "珍珠项链",
        "parentId": 6001271
    },
    {
        "categoryId": 6001277,
        "categoryName": "珍珠胸针",
        "parentId": 6001271
    },
    {
        "categoryId": 6001278,
        "categoryName": "钻石",
        "parentId": 6001202
    },
    {
        "categoryId": 6001279,
        "categoryName": "裸钻",
        "parentId": 6001278
    },
    {
        "categoryId": 6001280,
        "categoryName": "钻戒",
        "parentId": 6001278
    },
    {
        "categoryId": 6001281,
        "categoryName": "钻石耳饰",
        "parentId": 6001278
    },
    {
        "categoryId": 6001282,
        "categoryName": "钻石手镯/手链",
        "parentId": 6001278
    },
    {
        "categoryId": 6001283,
        "categoryName": "钻石项链/吊坠",
        "parentId": 6001278
    },
    {
        "categoryId": 6001284,
        "categoryName": "传统滋补",
        "parentId": 6000697
    },
    {
        "categoryId": 6001285,
        "categoryName": "定制工艺样",
        "parentId": 6000367
    },
    {
        "categoryId": 6001286,
        "categoryName": "定制工艺样",
        "parentId": 6000366
    },
    {
        "categoryId": 6001287,
        "categoryName": "定制工艺样",
        "parentId": 6000374
    },
    {
        "categoryId": 6001288,
        "categoryName": "定制工艺样",
        "parentId": 6000384
    },
    {
        "categoryId": 6001289,
        "categoryName": "定制工艺样",
        "parentId": 6000385
    },
    {
        "categoryId": 6001290,
        "categoryName": "定制工艺样",
        "parentId": 6000380
    },
    {
        "categoryId": 6001291,
        "categoryName": "定制工艺样",
        "parentId": 6000390
    },
    {
        "categoryId": 6001292,
        "categoryName": "定制工艺样",
        "parentId": 6000406
    },
    {
        "categoryId": 6001293,
        "categoryName": "定制工艺样",
        "parentId": 6000412
    },
    {
        "categoryId": 6001294,
        "categoryName": "定制工艺样",
        "parentId": 6000432
    },
    {
        "categoryId": 6001295,
        "categoryName": "定制工艺样",
        "parentId": 6000433
    },
    {
        "categoryId": 6001296,
        "categoryName": "定制工艺样",
        "parentId": 6000512
    },
    {
        "categoryId": 6001297,
        "categoryName": "定制工艺样",
        "parentId": 6000579
    },
    {
        "categoryId": 6001298,
        "categoryName": "定制工艺样",
        "parentId": 6000582
    },
    {
        "categoryId": 6001299,
        "categoryName": "定制工艺样",
        "parentId": 6000705
    },
    {
        "categoryId": 6001300,
        "categoryName": "定制工艺样",
        "parentId": 6000707
    },
    {
        "categoryId": 6001301,
        "categoryName": "定制工艺样",
        "parentId": 6000708
    },
    {
        "categoryId": 6001302,
        "categoryName": "定制工艺样",
        "parentId": 6000709
    },
    {
        "categoryId": 6001303,
        "categoryName": "定制工艺样",
        "parentId": 6000720
    },
    {
        "categoryId": 6001304,
        "categoryName": "定制工艺样",
        "parentId": 6000754
    },
    {
        "categoryId": 6001305,
        "categoryName": "定制工艺样",
        "parentId": 6000755
    },
    {
        "categoryId": 6001306,
        "categoryName": "水暖毯",
        "parentId": 900101
    },
    {
        "categoryId": 6001307,
        "categoryName": "滑雪包",
        "parentId": 31601
    },
    {
        "categoryId": 6001308,
        "categoryName": "干果机",
        "parentId": 900100
    },
    {
        "categoryId": 6001309,
        "categoryName": "宠物包",
        "parentId": 31601
    },
    {
        "categoryId": 6001310,
        "categoryName": "制冰机",
        "parentId": 900101
    },
    {
        "categoryId": 80001000,
        "categoryName": "女士拖鞋/人字拖",
        "parentId": 10
    },
    {
        "categoryId": 80001001,
        "categoryName": "女士板鞋",
        "parentId": 10
    },
    {
        "categoryId": 80001500,
        "categoryName": "男靴",
        "parentId": 15
    },
    {
        "categoryId": 80001501,
        "categoryName": "豆豆鞋",
        "parentId": 15
    },
    {
        "categoryId": 80002101,
        "categoryName": "女袜",
        "parentId": 21
    },
    {
        "categoryId": 80002103,
        "categoryName": "少女文胸",
        "parentId": 21
    },
    {
        "categoryId": 80002104,
        "categoryName": "男袜",
        "parentId": 21
    },
    {
        "categoryId": 80002105,
        "categoryName": "丝袜",
        "parentId": 21
    },
    {
        "categoryId": 80002106,
        "categoryName": "内搭打底衫",
        "parentId": 21
    },
    {
        "categoryId": 80002107,
        "categoryName": "打底袜",
        "parentId": 21
    },
    {
        "categoryId": 80002108,
        "categoryName": "家居服",
        "parentId": 21
    },
    {
        "categoryId": 80002400,
        "categoryName": "女士腰带",
        "parentId": 24
    },
    {
        "categoryId": 80002402,
        "categoryName": "羊绒/羊毛围巾/披肩",
        "parentId": 24
    },
    {
        "categoryId": 80002403,
        "categoryName": "领带/领结/领夹",
        "parentId": 24
    },
    {
        "categoryId": 80002700,
        "categoryName": "亲子装",
        "parentId": 27
    },
    {
        "categoryId": 80002701,
        "categoryName": "童袜",
        "parentId": 27
    },
    {
        "categoryId": 80002702,
        "categoryName": "帽子围巾手套",
        "parentId": 27
    },
    {
        "categoryId": 80002703,
        "categoryName": "套装",
        "parentId": 27
    },
    {
        "categoryId": 80002704,
        "categoryName": "家居服睡衣裤",
        "parentId": 27
    },
    {
        "categoryId": 80002705,
        "categoryName": "保暖内衣秋衣裤",
        "parentId": 27
    },
    {
        "categoryId": 80002706,
        "categoryName": "针织衫",
        "parentId": 27
    },
    {
        "categoryId": 80002707,
        "categoryName": "卫衣绒衫",
        "parentId": 27
    },
    {
        "categoryId": 80002708,
        "categoryName": "衬衫",
        "parentId": 27
    },
    {
        "categoryId": 80002709,
        "categoryName": "儿童马甲",
        "parentId": 27
    },
    {
        "categoryId": 80002710,
        "categoryName": "背心吊带",
        "parentId": 27
    },
    {
        "categoryId": 80002711,
        "categoryName": "裙子",
        "parentId": 27
    },
    {
        "categoryId": 80002712,
        "categoryName": "儿童皮肤衣/防晒服",
        "parentId": 27
    },
    {
        "categoryId": 80002713,
        "categoryName": "儿童泳装裤",
        "parentId": 27
    },
    {
        "categoryId": 80004500,
        "categoryName": "衣柜",
        "parentId": 45
    },
    {
        "categoryId": 80004501,
        "categoryName": "斗柜",
        "parentId": 45
    },
    {
        "categoryId": 80004502,
        "categoryName": "梳妆台/凳",
        "parentId": 45
    },
    {
        "categoryId": 80004503,
        "categoryName": "穿衣镜",
        "parentId": 45
    },
    {
        "categoryId": 80004600,
        "categoryName": "电视柜",
        "parentId": 46
    },
    {
        "categoryId": 80004601,
        "categoryName": "鞋柜",
        "parentId": 46
    },
    {
        "categoryId": 80004602,
        "categoryName": "休闲椅/凳",
        "parentId": 46
    },
    {
        "categoryId": 80004800,
        "categoryName": "奶锅",
        "parentId": 48
    },
    {
        "categoryId": 80004801,
        "categoryName": "锅具套装",
        "parentId": 48
    },
    {
        "categoryId": 80004802,
        "categoryName": "火锅",
        "parentId": 48
    },
    {
        "categoryId": 80004803,
        "categoryName": "烧水壶",
        "parentId": 48
    },
    {
        "categoryId": 80004804,
        "categoryName": "砂锅/石锅",
        "parentId": 48
    },
    {
        "categoryId": 80004900,
        "categoryName": "玻璃杯",
        "parentId": 49
    },
    {
        "categoryId": 80004903,
        "categoryName": "酒杯/酒具",
        "parentId": 49
    },
    {
        "categoryId": 80004904,
        "categoryName": "茶具",
        "parentId": 49
    },
    {
        "categoryId": 80004905,
        "categoryName": "陶瓷/马克杯",
        "parentId": 49
    },
    {
        "categoryId": 80004906,
        "categoryName": "水具套装",
        "parentId": 49
    },
    {
        "categoryId": 80005100,
        "categoryName": "层架/置物架",
        "parentId": 51
    },
    {
        "categoryId": 80006200,
        "categoryName": "马桶",
        "parentId": 62
    },
    {
        "categoryId": 80006201,
        "categoryName": "浴室柜",
        "parentId": 62
    },
    {
        "categoryId": 80006202,
        "categoryName": "浴霸",
        "parentId": 62
    },
    {
        "categoryId": 80006203,
        "categoryName": "水槽",
        "parentId": 62
    },
    {
        "categoryId": 80006204,
        "categoryName": "地漏",
        "parentId": 62
    },
    {
        "categoryId": 80006300,
        "categoryName": "落地灯",
        "parentId": 63
    },
    {
        "categoryId": 80006301,
        "categoryName": "吸顶灯",
        "parentId": 63
    },
    {
        "categoryId": 80006302,
        "categoryName": "装饰灯",
        "parentId": 63
    },
    {
        "categoryId": 80006303,
        "categoryName": "吊灯",
        "parentId": 63
    },
    {
        "categoryId": 80006304,
        "categoryName": "筒灯射灯",
        "parentId": 63
    },
    {
        "categoryId": 80010100,
        "categoryName": "合页",
        "parentId": 800101
    },
    {
        "categoryId": 80010101,
        "categoryName": "门吸",
        "parentId": 800101
    },
    {
        "categoryId": 80010200,
        "categoryName": "机械锁",
        "parentId": 800102
    },
    {
        "categoryId": 80010201,
        "categoryName": "工具箱/包",
        "parentId": 800102
    },
    {
        "categoryId": 80010303,
        "categoryName": "地毯",
        "parentId": 800103
    },
    {
        "categoryId": 80010304,
        "categoryName": "装饰摆件",
        "parentId": 800103
    },
    {
        "categoryId": 80010400,
        "categoryName": "收纳用品",
        "parentId": 800104
    },
    {
        "categoryId": 80010402,
        "categoryName": "梳子",
        "parentId": 800104
    },
    {
        "categoryId": 80010408,
        "categoryName": "厨房收纳",
        "parentId": 800104
    },
    {
        "categoryId": 80010500,
        "categoryName": "接线板/排插",
        "parentId": 800105
    },
    {
        "categoryId": 80010501,
        "categoryName": "开关插座",
        "parentId": 800105
    },
    {
        "categoryId": 80032200,
        "categoryName": "衬衫",
        "parentId": 322
    },
    {
        "categoryId": 80032201,
        "categoryName": "羽绒服",
        "parentId": 322
    },
    {
        "categoryId": 80032202,
        "categoryName": "棉服",
        "parentId": 322
    },
    {
        "categoryId": 80032203,
        "categoryName": "风衣",
        "parentId": 322
    },
    {
        "categoryId": 80032204,
        "categoryName": "大衣",
        "parentId": 322
    },
    {
        "categoryId": 80032205,
        "categoryName": "卫衣",
        "parentId": 322
    },
    {
        "categoryId": 80032206,
        "categoryName": "马甲/背心",
        "parentId": 322
    },
    {
        "categoryId": 80032207,
        "categoryName": "牛仔上衣",
        "parentId": 322
    },
    {
        "categoryId": 80032208,
        "categoryName": "牛仔裤",
        "parentId": 322
    },
    {
        "categoryId": 80032209,
        "categoryName": "休闲裤",
        "parentId": 322
    },
    {
        "categoryId": 80032210,
        "categoryName": "正装裤",
        "parentId": 322
    },
    {
        "categoryId": 80032211,
        "categoryName": "西服套装",
        "parentId": 322
    },
    {
        "categoryId": 80032212,
        "categoryName": "西裤",
        "parentId": 322
    },
    {
        "categoryId": 80032213,
        "categoryName": "羊毛衫",
        "parentId": 322
    },
    {
        "categoryId": 80032214,
        "categoryName": "羊绒衫",
        "parentId": 322
    },
    {
        "categoryId": 80032215,
        "categoryName": "真皮皮衣",
        "parentId": 322
    },
    {
        "categoryId": 80032217,
        "categoryName": "卫裤/运动裤",
        "parentId": 322
    },
    {
        "categoryId": 80032218,
        "categoryName": "短裤",
        "parentId": 322
    },
    {
        "categoryId": 80032219,
        "categoryName": "牛仔短裤",
        "parentId": 322
    },
    {
        "categoryId": 80032300,
        "categoryName": "短裤",
        "parentId": 323
    },
    {
        "categoryId": 80032301,
        "categoryName": "T恤",
        "parentId": 323
    },
    {
        "categoryId": 80032302,
        "categoryName": "半身裙",
        "parentId": 323
    },
    {
        "categoryId": 80032303,
        "categoryName": "雪纺衫/蕾丝衫",
        "parentId": 323
    },
    {
        "categoryId": 80032304,
        "categoryName": "卫衣",
        "parentId": 323
    },
    {
        "categoryId": 80032305,
        "categoryName": "西装",
        "parentId": 323
    },
    {
        "categoryId": 80032306,
        "categoryName": "外套",
        "parentId": 323
    },
    {
        "categoryId": 80032307,
        "categoryName": "马夹",
        "parentId": 323
    },
    {
        "categoryId": 80032308,
        "categoryName": "牛仔上衣",
        "parentId": 323
    },
    {
        "categoryId": 80032309,
        "categoryName": "牛仔裤",
        "parentId": 323
    },
    {
        "categoryId": 80032310,
        "categoryName": "连衣裙",
        "parentId": 323
    },
    {
        "categoryId": 80032311,
        "categoryName": "羽绒服",
        "parentId": 323
    },
    {
        "categoryId": 80032312,
        "categoryName": "棉服",
        "parentId": 323
    },
    {
        "categoryId": 80032313,
        "categoryName": "毛呢大衣",
        "parentId": 323
    },
    {
        "categoryId": 80032314,
        "categoryName": "真皮皮衣",
        "parentId": 323
    },
    {
        "categoryId": 80032315,
        "categoryName": "风衣",
        "parentId": 323
    },
    {
        "categoryId": 80032316,
        "categoryName": "羊毛衫",
        "parentId": 323
    },
    {
        "categoryId": 80032317,
        "categoryName": "羊绒衫",
        "parentId": 323
    },
    {
        "categoryId": 80032318,
        "categoryName": "衬衫",
        "parentId": 323
    },
    {
        "categoryId": 80032319,
        "categoryName": "皮草",
        "parentId": 323
    },
    {
        "categoryId": 80032320,
        "categoryName": "礼服",
        "parentId": 323
    },
    {
        "categoryId": 80032322,
        "categoryName": "牛仔短裤",
        "parentId": 323
    },
    {
        "categoryId": 80032323,
        "categoryName": "牛仔裙",
        "parentId": 323
    },
    {
        "categoryId": 80040100,
        "categoryName": "月子服",
        "parentId": 800401
    },
    {
        "categoryId": 80040101,
        "categoryName": "孕妇装",
        "parentId": 800401
    },
    {
        "categoryId": 80040102,
        "categoryName": "哺乳文胸",
        "parentId": 800401
    },
    {
        "categoryId": 80040104,
        "categoryName": "哺乳装/喂奶衣",
        "parentId": 800401
    },
    {
        "categoryId": 80040105,
        "categoryName": "孕产妇内裤",
        "parentId": 800401
    },
    {
        "categoryId": 80040106,
        "categoryName": "孕妇鞋",
        "parentId": 800401
    },
    {
        "categoryId": 80040200,
        "categoryName": "连身衣/爬服/哈衣",
        "parentId": 800402
    },
    {
        "categoryId": 80040201,
        "categoryName": "婴儿内衣",
        "parentId": 800402
    },
    {
        "categoryId": 80040203,
        "categoryName": "婴幼外出服套装",
        "parentId": 800402
    },
    {
        "categoryId": 80040204,
        "categoryName": "婴幼外套夹克",
        "parentId": 800402
    },
    {
        "categoryId": 80040205,
        "categoryName": "婴幼毛衣针织",
        "parentId": 800402
    },
    {
        "categoryId": 80040206,
        "categoryName": "婴幼棉服",
        "parentId": 800402
    },
    {
        "categoryId": 80040207,
        "categoryName": "婴幼裤子",
        "parentId": 800402
    },
    {
        "categoryId": 80040208,
        "categoryName": "婴幼裙子",
        "parentId": 800402
    },
    {
        "categoryId": 80040210,
        "categoryName": "帽子",
        "parentId": 800402
    },
    {
        "categoryId": 80040211,
        "categoryName": "婴儿礼盒",
        "parentId": 800402
    },
    {
        "categoryId": 80040212,
        "categoryName": "罩衣反穿衣",
        "parentId": 800402
    },
    {
        "categoryId": 80040213,
        "categoryName": "抱被睡袋抱毯",
        "parentId": 800402
    },
    {
        "categoryId": 80040214,
        "categoryName": "围兜口水巾",
        "parentId": 800402
    },
    {
        "categoryId": 80040215,
        "categoryName": "吸汗巾垫背巾",
        "parentId": 800402
    },
    {
        "categoryId": 80040216,
        "categoryName": "隔尿垫巾",
        "parentId": 800402
    },
    {
        "categoryId": 80040218,
        "categoryName": "婴儿床品套件",
        "parentId": 800402
    },
    {
        "categoryId": 80040219,
        "categoryName": "枕头/床垫/床单/围靠",
        "parentId": 800402
    },
    {
        "categoryId": 80040220,
        "categoryName": "毛毯盖毯被子",
        "parentId": 800402
    },
    {
        "categoryId": 80040221,
        "categoryName": "背袋/背巾/腰凳",
        "parentId": 800402
    },
    {
        "categoryId": 80040300,
        "categoryName": "婴儿玩具",
        "parentId": 800403
    },
    {
        "categoryId": 80040302,
        "categoryName": "积木拼插",
        "parentId": 800403
    },
    {
        "categoryId": 80040303,
        "categoryName": "模型玩具",
        "parentId": 800403
    },
    {
        "categoryId": 80040304,
        "categoryName": "健身玩具",
        "parentId": 800403
    },
    {
        "categoryId": 80040305,
        "categoryName": "毛绒布艺",
        "parentId": 800403
    },
    {
        "categoryId": 80040306,
        "categoryName": "绘画/DIY",
        "parentId": 800403
    },
    {
        "categoryId": 80040307,
        "categoryName": "摇车",
        "parentId": 800403
    },
    {
        "categoryId": 80040400,
        "categoryName": "纸尿裤",
        "parentId": 800404
    },
    {
        "categoryId": 80040500,
        "categoryName": "奶瓶奶嘴",
        "parentId": 800405
    },
    {
        "categoryId": 80040503,
        "categoryName": "水壶水杯",
        "parentId": 800405
    },
    {
        "categoryId": 80040504,
        "categoryName": "儿童餐具",
        "parentId": 800405
    },
    {
        "categoryId": 80190100,
        "categoryName": "T恤",
        "parentId": 801901
    },
    {
        "categoryId": 80190101,
        "categoryName": "卫衣/套头衫",
        "parentId": 801901
    },
    {
        "categoryId": 80190102,
        "categoryName": "夹克/外套",
        "parentId": 801901
    },
    {
        "categoryId": 80190103,
        "categoryName": "运动长裤",
        "parentId": 801901
    },
    {
        "categoryId": 80190104,
        "categoryName": "运动套装",
        "parentId": 801901
    },
    {
        "categoryId": 80190105,
        "categoryName": "运动短裤",
        "parentId": 801901
    },
    {
        "categoryId": 80190106,
        "categoryName": "运动羽绒服/棉服",
        "parentId": 801901
    },
    {
        "categoryId": 80190107,
        "categoryName": "泳装",
        "parentId": 801901
    },
    {
        "categoryId": 80190108,
        "categoryName": "健身服",
        "parentId": 801901
    },
    {
        "categoryId": 80190109,
        "categoryName": "运动马甲",
        "parentId": 801901
    },
    {
        "categoryId": 80190110,
        "categoryName": "运动配饰",
        "parentId": 801901
    },
    {
        "categoryId": 80190111,
        "categoryName": "运动袜",
        "parentId": 801901
    },
    {
        "categoryId": 80190300,
        "categoryName": "羽毛球",
        "parentId": 801903
    },
    {
        "categoryId": 80190301,
        "categoryName": "瑜伽",
        "parentId": 801903
    },
    {
        "categoryId": 80520001,
        "categoryName": "刀具及套装",
        "parentId": 805200
    },
    {
        "categoryId": 80520002,
        "categoryName": "厨房剪刀",
        "parentId": 805200
    },
    {
        "categoryId": 80520003,
        "categoryName": "瓜果刀/刨",
        "parentId": 805200
    },
    {
        "categoryId": 80520004,
        "categoryName": "砧板",
        "parentId": 805200
    },
    {
        "categoryId": 80520100,
        "categoryName": "餐具套装",
        "parentId": 805201
    },
    {
        "categoryId": 80520101,
        "categoryName": "碗",
        "parentId": 805201
    },
    {
        "categoryId": 80520102,
        "categoryName": "筷子",
        "parentId": 805201
    },
    {
        "categoryId": 80520200,
        "categoryName": "烹饪工具/厨用小工具",
        "parentId": 805202
    },
    {
        "categoryId": 80520201,
        "categoryName": "储物/置物架",
        "parentId": 805202
    },
    {
        "categoryId": 80520202,
        "categoryName": "保鲜盒/密封罐/调料罐",
        "parentId": 805202
    },
    {
        "categoryId": 80520203,
        "categoryName": "饭盒/提锅",
        "parentId": 805202
    },
    {
        "categoryId": 80520204,
        "categoryName": "厨房清洁洗涤用品",
        "parentId": 805202
    },
    {
        "categoryId": 80700001,
        "categoryName": "牙膏",
        "parentId": 807000
    },
    {
        "categoryId": 80700002,
        "categoryName": "漱口水",
        "parentId": 807000
    },
    {
        "categoryId": 80700101,
        "categoryName": "洁面",
        "parentId": 7001
    },
    {
        "categoryId": 80700102,
        "categoryName": "乳液面霜",
        "parentId": 7001
    },
    {
        "categoryId": 80700103,
        "categoryName": "爽肤水",
        "parentId": 7001
    },
    {
        "categoryId": 80700104,
        "categoryName": "眼部护理",
        "parentId": 7001
    },
    {
        "categoryId": 80700105,
        "categoryName": "精华",
        "parentId": 7001
    },
    {
        "categoryId": 80700106,
        "categoryName": "唇部护理",
        "parentId": 7001
    },
    {
        "categoryId": 80700107,
        "categoryName": "卸妆",
        "parentId": 7001
    },
    {
        "categoryId": 80700200,
        "categoryName": "洗护",
        "parentId": 7002
    },
    {
        "categoryId": 80700201,
        "categoryName": "洗发",
        "parentId": 807002
    },
    {
        "categoryId": 80700202,
        "categoryName": "沐浴",
        "parentId": 7002
    },
    {
        "categoryId": 80700203,
        "categoryName": "润肤",
        "parentId": 7002
    },
    {
        "categoryId": 80700204,
        "categoryName": "手足",
        "parentId": 7002
    },
    {
        "categoryId": 80700205,
        "categoryName": "精油",
        "parentId": 7002
    },
    {
        "categoryId": 80700206,
        "categoryName": "香皂",
        "parentId": 7002
    },
    {
        "categoryId": 80700207,
        "categoryName": "护发",
        "parentId": 807002
    },
    {
        "categoryId": 80700208,
        "categoryName": "护发精油",
        "parentId": 807002
    },
    {
        "categoryId": 80700300,
        "categoryName": "男士香水",
        "parentId": 807003
    },
    {
        "categoryId": 80700301,
        "categoryName": "女士香水",
        "parentId": 807003
    },
    {
        "categoryId": 80700302,
        "categoryName": "底妆",
        "parentId": 807003
    },
    {
        "categoryId": 80700303,
        "categoryName": "卸妆",
        "parentId": 807003
    },
    {
        "categoryId": 80700304,
        "categoryName": "口红/唇膏",
        "parentId": 807003
    },
    {
        "categoryId": 80700305,
        "categoryName": "眼妆",
        "parentId": 807003
    },
    {
        "categoryId": 80700306,
        "categoryName": "眉笔/眉粉/眉膏",
        "parentId": 807003
    },
    {
        "categoryId": 80700307,
        "categoryName": "化妆工具",
        "parentId": 807003
    },
    {
        "categoryId": 80700500,
        "categoryName": "洁面",
        "parentId": 807005
    },
    {
        "categoryId": 80700501,
        "categoryName": "面膜",
        "parentId": 807005
    },
    {
        "categoryId": 80700502,
        "categoryName": "爽肤水",
        "parentId": 807005
    },
    {
        "categoryId": 80700503,
        "categoryName": "男士乳液/面霜",
        "parentId": 807005
    },
    {
        "categoryId": 80700504,
        "categoryName": "防晒",
        "parentId": 807005
    },
    {
        "categoryId": 80710100,
        "categoryName": "儿童床品",
        "parentId": 7101
    },
    {
        "categoryId": 80710101,
        "categoryName": "被套",
        "parentId": 7101
    },
    {
        "categoryId": 80710102,
        "categoryName": "床单",
        "parentId": 7101
    },
    {
        "categoryId": 80710103,
        "categoryName": "床垫床褥",
        "parentId": 7101
    },
    {
        "categoryId": 80710104,
        "categoryName": "毛毯休闲毯",
        "parentId": 7101
    },
    {
        "categoryId": 80710105,
        "categoryName": "婚庆床品",
        "parentId": 7101
    },
    {
        "categoryId": 80710106,
        "categoryName": "凉席套件",
        "parentId": 7101
    },
    {
        "categoryId": 80710107,
        "categoryName": "蚊帐",
        "parentId": 7101
    },
    {
        "categoryId": 80710200,
        "categoryName": "蚕丝被",
        "parentId": 7102
    },
    {
        "categoryId": 80710201,
        "categoryName": "棉被",
        "parentId": 7102
    },
    {
        "categoryId": 80710202,
        "categoryName": "纤维被",
        "parentId": 7102
    },
    {
        "categoryId": 80710204,
        "categoryName": "羊毛被/驼毛被",
        "parentId": 7102
    },
    {
        "categoryId": 80710206,
        "categoryName": "空调毯",
        "parentId": 7102
    },
    {
        "categoryId": 80710300,
        "categoryName": "纤维枕",
        "parentId": 7103
    },
    {
        "categoryId": 80710301,
        "categoryName": "乳胶枕",
        "parentId": 7103
    },
    {
        "categoryId": 80710302,
        "categoryName": "保健枕",
        "parentId": 7103
    },
    {
        "categoryId": 80710303,
        "categoryName": "记忆枕",
        "parentId": 7103
    },
    {
        "categoryId": 80710304,
        "categoryName": "蚕丝枕",
        "parentId": 7103
    },
    {
        "categoryId": 80710400,
        "categoryName": "毯子",
        "parentId": 7104
    },
    {
        "categoryId": 80710401,
        "categoryName": "布艺家居拖鞋",
        "parentId": 7104
    },
    {
        "categoryId": 80710402,
        "categoryName": "坐垫",
        "parentId": 7104
    },
    {
        "categoryId": 80710403,
        "categoryName": "抱枕靠垫",
        "parentId": 7104
    },
    {
        "categoryId": 80710404,
        "categoryName": "窗帘窗纱",
        "parentId": 7104
    },
    {
        "categoryId": 80710405,
        "categoryName": "地毯",
        "parentId": 7104
    },
    {
        "categoryId": 80710406,
        "categoryName": "桌布罩件",
        "parentId": 7104
    },
    {
        "categoryId": 80710407,
        "categoryName": "颈枕",
        "parentId": 7104
    },
    {
        "categoryId": 83160000,
        "categoryName": "钱包",
        "parentId": 831600
    },
    {
        "categoryId": 83160001,
        "categoryName": "手拿包",
        "parentId": 831600
    },
    {
        "categoryId": 83160002,
        "categoryName": "单肩包",
        "parentId": 831600
    },
    {
        "categoryId": 83160003,
        "categoryName": "双肩包",
        "parentId": 831600
    },
    {
        "categoryId": 83160004,
        "categoryName": "手提包",
        "parentId": 831600
    },
    {
        "categoryId": 83160005,
        "categoryName": "斜挎包",
        "parentId": 831600
    },
    {
        "categoryId": 83160006,
        "categoryName": "钥匙包",
        "parentId": 831600
    },
    {
        "categoryId": 83160007,
        "categoryName": "卡包/零钱包",
        "parentId": 831600
    },
    {
        "categoryId": 83160100,
        "categoryName": "电脑数码包",
        "parentId": 31601
    },
    {
        "categoryId": 83160101,
        "categoryName": "旅行包/袋",
        "parentId": 31601
    },
    {
        "categoryId": 83160102,
        "categoryName": "休闲运动包",
        "parentId": 31601
    },
    {
        "categoryId": 83160103,
        "categoryName": "儿童书包",
        "parentId": 31601
    },
    {
        "categoryId": 83160104,
        "categoryName": "登山包",
        "parentId": 31601
    },
    {
        "categoryId": 83160105,
        "categoryName": "收纳包",
        "parentId": 31601
    },
    {
        "categoryId": 83160107,
        "categoryName": "妈咪包",
        "parentId": 31601
    },
    {
        "categoryId": 83160108,
        "categoryName": "儿童拉杆箱",
        "parentId": 31601
    },
    {
        "categoryId": 83160110,
        "categoryName": "笔袋",
        "parentId": 31601
    },
    {
        "categoryId": 83160200,
        "categoryName": "商务公文包",
        "parentId": 31602
    },
    {
        "categoryId": 83160201,
        "categoryName": "钱包/卡包",
        "parentId": 31602
    },
    {
        "categoryId": 83160202,
        "categoryName": "单肩/斜挎包",
        "parentId": 31602
    },
    {
        "categoryId": 83160203,
        "categoryName": "钥匙包",
        "parentId": 31602
    },
    {
        "categoryId": 83160204,
        "categoryName": "手拿包",
        "parentId": 31602
    },
    {
        "categoryId": 90000000,
        "categoryName": "手机保护套/壳",
        "parentId": 900000
    },
    {
        "categoryId": 90000001,
        "categoryName": "充电器",
        "parentId": 900000
    },
    {
        "categoryId": 90000002,
        "categoryName": "数据线",
        "parentId": 900000
    },
    {
        "categoryId": 90000005,
        "categoryName": "移动电源",
        "parentId": 900000
    },
    {
        "categoryId": 90000100,
        "categoryName": "耳机/耳麦",
        "parentId": 900001
    },
    {
        "categoryId": 90000101,
        "categoryName": "便携/无线音箱",
        "parentId": 900001
    },
    {
        "categoryId": 90000102,
        "categoryName": "音箱/音响",
        "parentId": 900001
    },
    {
        "categoryId": 90010000,
        "categoryName": "咖啡机",
        "parentId": 900100
    },
    {
        "categoryId": 90010001,
        "categoryName": "榨汁机",
        "parentId": 900100
    },
    {
        "categoryId": 90010002,
        "categoryName": "面包机",
        "parentId": 900100
    },
    {
        "categoryId": 90010003,
        "categoryName": "电烤箱",
        "parentId": 900100
    },
    {
        "categoryId": 90010004,
        "categoryName": "电水壶",
        "parentId": 900100
    },
    {
        "categoryId": 90010005,
        "categoryName": "电磁炉",
        "parentId": 900100
    },
    {
        "categoryId": 90010100,
        "categoryName": "电风扇",
        "parentId": 900101
    },
    {
        "categoryId": 90010101,
        "categoryName": "吸尘器",
        "parentId": 900101
    },
    {
        "categoryId": 90010102,
        "categoryName": "空气净化器",
        "parentId": 900101
    },
    {
        "categoryId": 90010200,
        "categoryName": "电动牙刷",
        "parentId": 900102
    },
    {
        "categoryId": 90010201,
        "categoryName": "直发器",
        "parentId": 900102
    },
    {
        "categoryId": 90020000,
        "categoryName": "脚垫",
        "parentId": 900200
    },
    {
        "categoryId": 90020001,
        "categoryName": "座垫",
        "parentId": 900200
    },
    {
        "categoryId": 90020002,
        "categoryName": "后备箱垫",
        "parentId": 900200
    },
    {
        "categoryId": 90020003,
        "categoryName": "方向盘套",
        "parentId": 900200
    },
    {
        "categoryId": 90020004,
        "categoryName": "头枕腰枕",
        "parentId": 900200
    },
    {
        "categoryId": 90020100,
        "categoryName": "车载净化器",
        "parentId": 900201
    },
    {
        "categoryId": 90020101,
        "categoryName": "车载充电器",
        "parentId": 900201
    }
]

/**
 * 获取类目选项
 * @returns 
 */
export const getCategoryOptions = () => {
    const obj = setTreeData(data);
    console.log(obj, '??????obj');
    return obj;
}