import axios from '../../services/axios';

export interface PassWordLoginParams {
    /** 用户名 */
    username: string;
    /** 密码 */
    password: string;
}

export const passwordlogin = async (params: PassWordLoginParams) => {
    axios.post('/user/login', {
        account: params.username,
        password: params.password,
        },{
            withCredentials: false,
        }
        )
        .then((response) => {
        console.log(response, '???response');
        
        // resolve(response);
        })
        .catch((error) => {
        console.log(error, '???error');
        // resolve(error);
        });
    //   return new Promise<Partial<UserInfo>>((resolve) => {
    //     axios.post('/user/login', {
    //         account: params.username,
    //         password: params.password,
    //       },
    //       {
    //         baseURL: 'http://local.aiyongtech.com:3000',
    //       }
    //       )
    //       .then((response) => {
    //         resolve(response);
    //       })
    //       .catch((error) => {
    //         resolve(error);
    //       });
    // });
};
